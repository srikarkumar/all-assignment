create database pathfrontado
use pathfrontado

create table tbl_employees1(
empid int identity(100,1),
empname varchar(100),
empcity varchar(100),
emppassword varchar(100),
empdoj datetime
)

select * from tbl_employees1

create table tbl_customers(
custid int identity(100,1) primary key,
custname varchar(100),
custpassword varchar(100),
custcity varchar(100),
custadd varchar(100),
custmobile varchar(100),
custmailid varchar(100))

select * from tbl_customers

