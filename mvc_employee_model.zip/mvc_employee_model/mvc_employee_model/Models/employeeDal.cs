﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace mvc_employee_model.Models
{
    public class employeeDal
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int addemployee(employeeModel e)
        {
            try
            {
                SqlCommand com_addemp = new SqlCommand("p_addemp", con);
                com_addemp.Parameters.AddWithValue("@name", e.employeename);
                com_addemp.Parameters.AddWithValue("@city", e.employeecity);
                com_addemp.Parameters.AddWithValue("@mail", e.employeemail);

                com_addemp.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_addemp.Parameters.Add(retdata);

                con.Open();
                com_addemp.ExecuteNonQuery();
                con.Close();

                int id = Convert.ToInt32(retdata.Value);
                return id;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public employeeModel findemployee(int id)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("p_find", con);
                com_find.Parameters.AddWithValue("@id", id);
                com_find.CommandType = CommandType.StoredProcedure;
                employeeModel emp = new employeeModel();
                con.Open();
                SqlDataReader dr = com_find.ExecuteReader();
                if (dr.Read())
                {

                    emp.employeeid = dr.GetInt32(0);
                    emp.employeename = dr.GetString(1);
                    emp.employeecity = dr.GetString(2);
                    emp.employeemail = dr.GetString(3);

                }
                return emp;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<employeeModel> searchemp(string key)
        {
            try { 
            List<employeeModel> elist = new List<employeeModel>();
            SqlCommand com_search = new SqlCommand("p_searchemp", con);
            com_search.Parameters.AddWithValue("@key", key);
                com_search.CommandType = CommandType.StoredProcedure;
                employeeModel emp = new employeeModel();
                con.Open();
                SqlDataReader dr = com_search.ExecuteReader();
                if (dr.Read())
                {

                    emp.employeeid = dr.GetInt32(0);
                    emp.employeename = dr.GetString(1);
                    emp.employeecity = dr.GetString(2);
                    emp.employeemail = dr.GetString(3);
                    elist.Add(emp);
                }
                return elist;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }




        }
        public bool deleteemployee(int id)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("p_delete", con);
                com_delete.Parameters.AddWithValue("@id", id);
                com_delete.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_delete.Parameters.Add(retdata);
                con.Open();
                com_delete.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool updateemployee(int id,string city, string mail)
        {
            try
            {
                SqlCommand com_update = new SqlCommand("p_update", con);
                com_update.Parameters.AddWithValue("@id", id);
                
                com_update.Parameters.AddWithValue("@mail", mail);
                com_update.Parameters.AddWithValue("@city", city);

                com_update.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_update.Parameters.Add(retdata);

                con.Open();
                com_update.ExecuteNonQuery();
                con.Close();

                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        }

        }


    
