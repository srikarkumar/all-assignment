﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc_employee_model.Models
{
    public class employeeModel
    {
        public int employeeid { get; set; }
        public string employeename { get; set; }
        public string employeecity { get; set; }
        public string employeemail { get; set; }
    }
}