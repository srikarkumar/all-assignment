﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvc_employee_model.Models;


namespace mvc_employee_model.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult addemployee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult addemployee(employeeModel model)
        {
            if (ModelState.IsValid)
            {
                employeeDal dal = new employeeDal();
                int id = dal.addemployee(model);
                ViewBag.msg = "employee id:" + id;
               
            }
            return View();
            
        }
        public ActionResult searchemployee()
        {
            return View();

        }
        [HttpPost]
        public ActionResult searchemployee(string key)
        {
            employeeDal dal = new employeeDal();
            List<employeeModel> list = dal.searchemp(key);
            return View(list);
        }
       
        public ActionResult delete(int id)
        {
            employeeDal dal = new employeeDal();
            dal.deleteemployee(id);
            return View();
        }
        public ActionResult details(int id)
        {
            employeeDal dal = new employeeDal();
            employeeModel model = dal.findemployee(id);
            return View(model);
        }
        public ActionResult edit(int id)
        {
            employeeDal dal = new employeeDal();
            employeeModel model = dal.findemployee(id);
            return View(model);
        }
        [HttpPost]
        public ActionResult edit(employeeModel model)
        {
            employeeDal dal = new employeeDal();
            dal.updateemployee(model.employeeid,model.employeecity, model.employeemail);
            return View("employeeupdatedview");
        }




    } }