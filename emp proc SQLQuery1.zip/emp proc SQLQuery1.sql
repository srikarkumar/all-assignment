select * from tbl_employees1
--1
create proc p_addemployee(@name varchar(100),@city varchar(100),@password varchar(100)) 
as
insert tbl_employees1 values(@name,@city,@password,getdate())
return @@identity
--2
create proc p_empdetails(@id int)
as
select * from tbl_employees1 where empid=@id;
--3
create proc p_showemp(@city varchar(100))as
select * from tbl_employees1 where empcity=@city;
--4
create proc p_searchemp(@key varchar(100))
as
select * from tbl_employees1 
where empid like '%'+@key+'%' or empcity like '%'+@key+'%' or empname like '%'+@key+'%'

--5
create proc p_updateemp(@id int,@city varchar(100),@password varchar(100))
as
update tbl_employees1 set empcity=@city, empname=@password where empid=@id
return @@rowcount


--6
create proc p_deleteemp(@id int)
as
delete tbl_employees1 where empid=@id;
return @@rowcount;

--7 
create proc p_login(@id int,@password varchar(100))as
declare @count int
select @count=count(*) from tbl_employees1 where empid=@id and emppassword=@password;
return @count;

declare @i int
exec @i= p_login 101,'ghi'
select @i

