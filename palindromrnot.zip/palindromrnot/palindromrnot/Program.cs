﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace palindromrnot
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, orgint, revint = 0,rem;
            Console.WriteLine("enter number");
            n = Convert.ToInt32(Console.ReadLine());
            orgint = n;
            while (n != 0)
            {
                rem = n%10;
                revint = revint * 10 + rem;
                n = n / 10;
            }
            if (orgint == revint)
            {
                Console.WriteLine("polindrom");
            }
            else
            {
                Console.WriteLine("not polindrom");
            }
            Console.ReadLine();
        }
        
    }
}
