﻿namespace Win_threads
{
    partial class frm_task
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnnewtask = new System.Windows.Forms.Button();
            this.btnnewtask2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnnewtask
            // 
            this.btnnewtask.Location = new System.Drawing.Point(94, 50);
            this.btnnewtask.Name = "btnnewtask";
            this.btnnewtask.Size = new System.Drawing.Size(102, 49);
            this.btnnewtask.TabIndex = 0;
            this.btnnewtask.Text = "new task";
            this.btnnewtask.UseVisualStyleBackColor = true;
            this.btnnewtask.Click += new System.EventHandler(this.btnnewtask_Click);
            // 
            // btnnewtask2
            // 
            this.btnnewtask2.Location = new System.Drawing.Point(94, 158);
            this.btnnewtask2.Name = "btnnewtask2";
            this.btnnewtask2.Size = new System.Drawing.Size(102, 49);
            this.btnnewtask2.TabIndex = 1;
            this.btnnewtask2.Text = "new task2";
            this.btnnewtask2.UseVisualStyleBackColor = true;
            this.btnnewtask2.Click += new System.EventHandler(this.btnnewtask2_Click);
            // 
            // frm_task
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 351);
            this.Controls.Add(this.btnnewtask2);
            this.Controls.Add(this.btnnewtask);
            this.Name = "frm_task";
            this.Text = "frm_task";
            this.Load += new System.EventHandler(this.frm_task_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnnewtask;
        private System.Windows.Forms.Button btnnewtask2;
    }
}