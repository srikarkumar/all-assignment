﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_threads
{
    public partial class Form_lockinh : Form
    {
        ReaderWriterLock rw = new ReaderWriterLock();
        int total;
        public void sum()
        {
            int n1 = Convert.ToInt32(txtn1.Text);
            int n2 = Convert.ToInt32(txtn2.Text);

            rw.AcquireReaderLock(Timeout.Infinite);
           // if (Monitor.TryEnter(this,3000))
           // {
                // lock (this)
                //{
                total = n1 + n2;
                Thread.Sleep(10000);
                MessageBox.Show("total:" + total);
            // }
            // Monitor.Exit(this);
            // }
            // else { MessageBox.Show("other task"); }
            rw.ReleaseLock();
        }
        public void sum1()
        {
            int n1 = Convert.ToInt32(txtn1.Text);
            int n2 = Convert.ToInt32(txtn2.Text);

            rw.AcquireWriterLock(Timeout.Infinite);
            
            total = n1 + n2;
            Thread.Sleep(10000);
            MessageBox.Show("total:" + total);
            
            rw.ReleaseLock();
        }
        public Form_lockinh()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(this.sum);
            th1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(this.sum1);
            th2.Start();
        }
    }
}
