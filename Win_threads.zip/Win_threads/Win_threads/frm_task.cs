﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_threads
{
    public partial class frm_task : Form
    {
        public frm_task()
        {
            InitializeComponent();
        }

        private void btnnewtask_Click(object sender, EventArgs e)
        {
            Task t1 = Task.Run(() =>
            {
                MessageBox.Show("task 1");
            });
            Task t2 = Task.Run(() =>
            {
                MessageBox.Show("task 2");
            });

        }

        private void frm_task_Load(object sender, EventArgs e)
        {

        }

        private async void btnnewtask2_Click(object sender, EventArgs e)
        {
            test obj = new test();
           var t= obj.addnumAsync(10, 20);//thread pool thread
            MessageBox.Show("some other work");

            int x = await t;
            MessageBox.Show("return data:" + x);
        }
    }
}
