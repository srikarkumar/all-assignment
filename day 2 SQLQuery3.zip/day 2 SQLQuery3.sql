create database pathfrontdb2
use PathfrontDB2

create table tbl_customers
(customerid int identity(1000,1)primary key,
customername varchar(100) not null,
customercity varchar(100)not null,
customermail varchar(100) not null unique,
customermobileno varchar(100) not null unique
)
insert tbl_customers values('srikar','hyd','123@abc','12345')
insert tbl_customers values('vinay','bng','dddd@abc','45651')
insert tbl_customers values('rahul','hyd','hhh@abc','85345')
insert tbl_customers values('gopi','viz','jdj@abc','187945')
insert tbl_customers values('ram','chennai','ff3@abc','123215')
select * from tbl_customers


create table tbl_items(
itemid int identity(1,1) primary key,
itemname varchar(100) not null ,
itemprice int check(itemprice>0)
)

insert tbl_items values('cap',100)
insert tbl_items values('gun',500)
insert tbl_items values('book',250)
insert tbl_items values('pen',150)
insert tbl_items values('phone',200)
select * from tbl_items

create table tbl_invoices(
invoiceid int identity(200,1) primary key,
customerid int not null foreign key references tbl_customers(customerid),
invoicecity varchar(100) not null,
invoicedate datetime not null,
invoiceaddress varchar(100)
)
insert tbl_invoices values(1000,'hyd',GETDATE(),'madhapur')
insert tbl_invoices values(1001,'bng',GETDATE(),'btm')
insert tbl_invoices values(1002,'viz',GETDATE(),'sim')
insert tbl_invoices values(1004,'hyd',GETDATE(),'amrpt')
insert tbl_invoices values(1003,'viz',GETDATE(),'beach')

select * from tbl_invoices



create table invoiceitems(
invoiceid int not null foreign key references tbl_invoices(invoiceid),
itemid int not null foreign key references tbl_items(itemid),
itemqty int check(itemqty>0),
itemprice int check(itemprice>0)primary key(invoiceid,itemid)
)

insert invoiceitems values(201,1,2,100)
insert invoiceitems values(203,2,1,150)
insert invoiceitems values(202,5,1,300)
insert invoiceitems values(201,2,3,150)
insert invoiceitems values(201,3,3,100)
insert invoiceitems values(205,4,10,200)
insert invoiceitems values(205,2,2,150)
insert invoiceitems values(206,4,10,200)
insert invoiceitems values(208,2,2,150)
insert invoiceitems values(207,4,5,200)


select * from tbl_customers where customerid  in(select customerid from tbl_invoices)--inner join

select * from tbl_customers where customerid not in(select customerid from tbl_invoices)

select * from tbl_items where itemid in(select itemid from tbl_invoices) 

select * from tbl_items where itemid not in(select itemid from tbl_invoices) 

select * from tbl_customers where customerid in (select top 1 customerid from tbl_invoices order by invoicedate desc)

select top 1 with ties * from tbl_invoices order by invoicedate desc 





create table tbl_employees
(
employeeid int identity(100,1) primary key,
employeename varchar(100) not null,
employeesalary int not null,
employeedept varchar(100),
managerid int foreign key references tbl_employees(employeeid)
)

insert tbl_employees values('john',20000,'hr',null)
insert tbl_employees values('rosy',16000,'hr',100)
insert tbl_employees values('xyz',20000,'it',null)
insert tbl_employees values('abc',18000,'it',102)


select * from tbl_employees e1 where e1.employeesalary>
(select avg(e2.employeesalary)from tbl_employees e2 where e2.employeedept=e1.employeedept)


select top 1 * from tbl_employees where employeeid not in (
select top 1 with ties employeeid from tbl_employees order by employeesalary desc
)order by employeesalary desc



select top 1 * from tbl_employees where employeeid  in (
select top 2 employeeid from tbl_employees order by employeesalary desc
)order by employeesalary asc


select tbl_customers.customerid,tbl_customers.customername,
tbl_invoices.invoiceid,tbl_invoices.invoicedate
 from tbl_customers join tbl_invoices
 on tbl_customers.customerid=tbl_invoices.customerid


 select tbl_invoices.invoiceid,tbl_invoices.customerid,tbl_invoices.invoicecity,
invoiceitems.itemid,invoiceitems.itemqty,tbl_items.itemname from tbl_invoices join invoiceitems  
on tbl_invoices.invoiceid=invoiceitems.invoiceid
join tbl_items 
on tbl_items.itemid= invoiceitems.



select * from tbl_customers cross join tbl_invoices

select e.employeeid,e.employeename,e.employeesalary,e.managerid,m.employeename
from tbl_employees e left outer join tbl_employees m
on e.managerid=m.employeeid


