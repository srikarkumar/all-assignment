create table tbl_student(
studentid int identity(100,1),
studentname varchar(100),
studentcity varchar(100),
studentaddress varchar(100),
studentmailid varchar(100)
)
select * from tbl_student