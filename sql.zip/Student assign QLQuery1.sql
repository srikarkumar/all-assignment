 create database studentdb
 use studentdb

 create table tbl_students(
 studentid int identity(100,1),
 studentname varchar(100),
 studentcity varchar(100),
 studentimageaddress varchar(100) not null

 )

 create proc p_addstudent(@name varchar(100),@city varchar(100),@address varchar(100))
 as
 insert tbl_students values(@name,@city,@address)
 return @@identity

 create proc p_search(@key varchar(100))

 as
 select * from tbl_students where studentid like '%'+@key+'%'
 or studentname like '%'+@key+'%'
  or studentcity like '%'+@key+'%'


  create proc p_details(@id int)
  as
  select * from tbl_students where studentid=@id

  create table tbl_books(bookid int identity(100,1), bookname varchar(100),authorname varchar(100),bookimage varchar(100));
drop table tbl_books
select * from tbl_books
  
  alter proc p_addbook(@bname varchar(100),@aname varchar(100),@image varchar(100))
  as
  insert tbl_books values(@bname,@aname,@image)
  return @@identity



  create proc p_searchbook(@key varchar(100))
as
select * from tbl_books where 
bookid like '%'+@key+'%'
or bookname like '%'+@key+'%'
or authorname like '%'+@key+'%'
or bookimage like '%'+@key+'%'
