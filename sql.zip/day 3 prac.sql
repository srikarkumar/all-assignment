create database empmanagementdb
use empmanagementdb

create table tbl_employees
(empid int,empname varchar(100),empcity varchar(100),empsalary int,
empdob date,empdoj date,empmobileno varchar(100),empmailid varchar(100),
emppassword varchar(100),empdept varchar(100)
)
select * from tbl_employees

create table tbl_emp_available_leaves
(empid int,sickleave int,causeleave int,
vacationleave int,compoff int)
insert tbl_emp_available_leaves values(6,50,12,5,5)

select * from tbl_emp_available_leaves

create table tbl_empleaves(empid int,leavetype varchar(100),
leaveapplydate date,leavedate date,noofleaves int)
insert tbl_empleaves values(5,'fvevger','10-8-2018','10-9-2018',4)
select * from tbl_empleaves

create table tbl_empsalary(empid int,empsalary int,
salarymonth int,salaryyear int,salarydate int)

insert tbl_empsalary values(5,4000,3,12,11)
select * from tbl_empsalary


--1
select * from tbl_employees where datepart(mm,empdoj)=datepart(mm,getdate())
--2
select * from tbl_employees where empsalary>20000
--3
select empdept,count(*)as 'no of in dept',sum(empsalary) as 'totalsal',avg(empsalary)as'avg sal' from tbl_employees group by empdept
--4
select tbl_employees.empid,tbl_employees.empname,
tbl_emp_available_leaves.sickleave,tbl_emp_available_leaves.causeleave,
tbl_emp_available_leaves.vacationleave,tbl_emp_available_leaves.compoff
from tbl_employees join tbl_emp_available_leaves 
on tbl_employees.empid=tbl_emp_available_leaves.empid

--5




--6
create proc p_1
as
insert tbl_emp_available_leaves values(10,10,4,5,7)

--7
create trigger trg_e on tbl_empleaves
for insert 
as
begin
declare @empid int
declare @leavetype varchar(100)
declare @noofeaves int
select @empid=empid,@leavetype=leavetype,@noofeaves=noofleaves from inserted
if(leavetype=sickleave)
begin
update tbl_emp_available_leaves set sickleave=sickleave-@noofeaves where empid=@empid
end
if(leavetype=causeleave)
begin
update tbl_emp_available_leaves set causeleave=causeleave-@noofeaves where empid=@empid
end
if(leavetype=vacationleave)
begin
update tbl_emp_available_leaves set vacationleave=vacationleave-@noofeaves where empid=@empid
end
if(leavetype=compoff)
begin
update tbl_emp_available_leaves set compoff=compoff-@noofeaves where empid=@empid
end

--8
create trigger trgg
for check
as
select salarymonth,salaryyear from tbl_empsalary
if(salarymonth<datepart(mm,getdate()))
begin
rollback
end
else
commit










