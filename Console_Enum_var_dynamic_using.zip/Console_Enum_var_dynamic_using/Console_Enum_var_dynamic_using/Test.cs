﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Console_Enum_var_dynamic_using;

namespace Console_Enum_var_dynamic_using1
{
    class Test
    {
        public void MakePayment(Paumenttype t)
        {
            Console.WriteLine(t);
        }  
        public static void call()
        {
        } 
    }
}
