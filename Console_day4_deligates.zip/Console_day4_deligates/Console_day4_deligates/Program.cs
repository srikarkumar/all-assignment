﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day4_deligates
{
    class Program
    {
        static void Main(string[] args)
        {
            Test obj = new Test();
            int x = 100;

            Test.del d = new Test.del(obj.call1);
            d += new Test.del(obj.call2);
            d -= new Test.del(obj.call1);
            d += new Test.del(obj.call1);

            d += delegate (string s)
            {
                Console.WriteLine("anymous code" + s + " " + x);
            };

            d += (s) => Console.WriteLine(s);// lambda expression

            d("hello");


            Console.ReadLine();



        }
    }
}
