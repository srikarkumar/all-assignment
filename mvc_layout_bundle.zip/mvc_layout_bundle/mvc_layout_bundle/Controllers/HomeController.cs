﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc_layout_bundle.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult contactinfo()
        {
            return View();
        }
        [Route("pathfront")]
        public ActionResult aboutus()
        {
            return View();
        }
        [Route("sendmessage/{msg}")]
        public ActionResult Getmessage(string msg)
        {
            ViewBag.msg = msg;
            return View();
        }

    }
}