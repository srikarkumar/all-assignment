﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_generic_Employee
{
    class Employee
    {
        public delegate void delleave(int id, string reason);
        public event delleave ent;

        private string EmployeeName;
        private string Employeecity;
        private int EmployeeId;
        public static int count = 1000;

        public Employee(string EmployeeName, string Employeecity)
        {
            Employee.count++;
            this.EmployeeId = Employee.count;
            this.EmployeeName = EmployeeName;
            this.Employeecity = Employeecity;
        }
        public string PEmployeeName { get { return this.EmployeeName; } }
        public string PEmployeeCity { get { return this.Employeecity; } }
        public int PEmployeeId { get { return this.EmployeeId; } }

        public void onleave(string reason)
        {
            if (this.ent != null)
            {
                this.ent(this.EmployeeId, reason);
            }
        }


    }
}
