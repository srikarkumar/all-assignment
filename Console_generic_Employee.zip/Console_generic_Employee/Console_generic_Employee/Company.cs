﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_generic_Employee
{
    class Company
    {
        public void onleave(int id,string reason)
        {
            Console.WriteLine("company class:" + id + " " + reason);
        }

        private string CompanyName;
        private string CompanyAddress;

        public Company(string CompanyName, string CompanyAddress)
        {
            this.CompanyName = CompanyName;
            this.CompanyAddress = CompanyAddress;
        }

        public string PCompanyName { get {return this.CompanyName; } }
        public string PCompanyaddress { get {return this.CompanyAddress; } }
        private List<Employee> EmployeeList = new List<Employee>();

        public void AddEmployee(Employee e)
        {
            Employee.delleave d= new Employee.delleave(this.onleave);
            e.ent += d;
            EmployeeList.Add(e);
         }
        public Employee SearchEmployee(int id)
        {

            foreach (Employee e in EmployeeList)
            {
                if (e.PEmployeeId == id)
                {
                    return e;
                }
                }
            return null;
        }
        public bool Remove(int ID)
        {
            foreach (Employee e in EmployeeList)
            {
                if (e.PEmployeeId == ID)
                {
                    EmployeeList.Remove(e);
                    return true;
                }
            }
            return false;
        }

        public void Show()
        {
            foreach (Employee e in EmployeeList)
            {
                Console.WriteLine(e.PEmployeeId + " " +e.PEmployeeName + " " + e.PEmployeeCity);
            }
        }


    }
}
