﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_attributes
{
    [dev_attribute(   "1000", "sri")]
    class test
    {
       
        [Obsolete("not in use,use xyz")]
        [dev_attribute("1002", "ssss")]
        public void call()
        {
            Console.WriteLine("call funt");

        }

    }
}
