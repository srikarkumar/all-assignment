﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<customer> custlist = new List<customer>();
            custlist.Add(new customer { customerid = 1, customerage = 23, customercity = "hyd", customername = "srikar1" });
            custlist.Add(new customer { customerid = 2, customerage = 24, customercity = "hyd1", customername = "srikar2" });
            custlist.Add(new customer { customerid = 3, customerage = 23, customercity = "hyd2", customername = "srikar3" });
            custlist.Add(new customer { customerid = 4, customerage = 33, customercity = "hyd", customername = "srikar4" });
            custlist.Add(new customer { customerid = 5, customerage = 13, customercity = "hyd4", customername = "srikar5" });


            List<odred> orderlist = new List<odred>();
            orderlist.Add(new odred { ordrid = 100, customerid = 1, itemname = "caps", itemprice = 100 });
            orderlist.Add(new odred { ordrid = 101, customerid = 1, itemname = "cap1", itemprice = 200 });
            orderlist.Add(new odred { ordrid = 102, customerid = 3, itemname = "cap2", itemprice = 300 });
            orderlist.Add(new odred { ordrid = 103, customerid = 4, itemname = "cap3", itemprice = 400 });
            orderlist.Add(new odred { ordrid = 104, customerid = 5, itemname = "cap4", itemprice = 500 });


            var data = custlist.Where((c) => c.customercity == "hyd");
            foreach(var x in data)
            {
                Console.WriteLine(x.customerid + " " + x.customername);
            }
            var count = custlist.Count((c) => c.customercity == "hyd");
            Console.WriteLine("count");

            var obj = custlist.FirstOrDefault((c) => c.customerid == 1);
            if (obj != null)
            {
                Console.WriteLine(obj.customerid+" "+obj.customername);
            }
            else { Console.WriteLine("not found"); }

            var status = custlist.Exists((c) => c.customerid == 1);
            Console.WriteLine(status);


            var dataprojection = custlist.Where((c) => c.customercity == "hyd").
            Select((s) => new { cid = s.customerid, cname = s.customername });

            foreach(var d in dataprojection)
            {
                Console.WriteLine(d.cid + " " + d.cname);
            }

            var dataorderby = custlist.Where((c) => c.customerage > 20).OrderBy((o) => o.customername).ThenByDescending((o1)=>o1.customercity);
            foreach(var d in dataorderby)
            {
                Console.WriteLine(d.customerid + " " + d.customername + " " + d.customercity);
            }

            var groupdata = custlist.GroupBy((g) => g.customercity).Select((s) => new {city = s.Key,count =s.Count(),avg =s.Average((a)=>a.customerage) });

            foreach(var x in groupdata)
            {
                Console.WriteLine(x.city + " " + x.count + " " + x.avg);
            }

            var joindata = custlist.Join(orderlist,
                (c) => c.customerid,
                (o) => o.customerid,
                (c, o)=> new { cid = c.customerid, cname = c.customername, oid = o.ordrid, iname = o.itemname, iprice = o.itemprice }).Where((c)=>c.iprice>200);
            foreach(var j in joindata)
            {
                Console.WriteLine(j.cid + " " + j.cname + " " + j.oid + " " + j.iname + " " + j.iprice);
            }



            Console.ReadLine();

        }
    }
}
