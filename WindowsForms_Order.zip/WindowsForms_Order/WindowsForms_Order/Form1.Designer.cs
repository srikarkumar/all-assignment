﻿namespace WindowsForms_Order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.txt_custname = new System.Windows.Forms.TextBox();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.txt_deliveryadd = new System.Windows.Forms.TextBox();
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_custname = new System.Windows.Forms.Label();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.lbl_deliveryadd = new System.Windows.Forms.Label();
            this.cmb_city = new System.Windows.Forms.ComboBox();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_paymentoption = new System.Windows.Forms.Label();
            this.rdb_online = new System.Windows.Forms.RadioButton();
            this.rdb_cash = new System.Windows.Forms.RadioButton();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_orderid
            // 
            this.txt_orderid.Location = new System.Drawing.Point(273, 39);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(100, 26);
            this.txt_orderid.TabIndex = 0;
            // 
            // txt_custname
            // 
            this.txt_custname.Location = new System.Drawing.Point(273, 99);
            this.txt_custname.Name = "txt_custname";
            this.txt_custname.Size = new System.Drawing.Size(100, 26);
            this.txt_custname.TabIndex = 1;
            // 
            // txt_itemid
            // 
            this.txt_itemid.Location = new System.Drawing.Point(273, 161);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(100, 26);
            this.txt_itemid.TabIndex = 2;
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.Location = new System.Drawing.Point(273, 215);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(100, 26);
            this.txt_itemqty.TabIndex = 3;
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Location = new System.Drawing.Point(273, 270);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(100, 26);
            this.txt_itemprice.TabIndex = 4;
            // 
            // txt_deliveryadd
            // 
            this.txt_deliveryadd.Location = new System.Drawing.Point(273, 339);
            this.txt_deliveryadd.Name = "txt_deliveryadd";
            this.txt_deliveryadd.Size = new System.Drawing.Size(100, 26);
            this.txt_deliveryadd.TabIndex = 5;
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Location = new System.Drawing.Point(71, 45);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(61, 20);
            this.lbl_orderid.TabIndex = 6;
            this.lbl_orderid.Text = "Orderid";
            // 
            // lbl_custname
            // 
            this.lbl_custname.AutoSize = true;
            this.lbl_custname.Location = new System.Drawing.Point(75, 105);
            this.lbl_custname.Name = "lbl_custname";
            this.lbl_custname.Size = new System.Drawing.Size(117, 20);
            this.lbl_custname.TabIndex = 7;
            this.lbl_custname.Text = "customerName";
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Location = new System.Drawing.Point(79, 167);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(51, 20);
            this.lbl_itemid.TabIndex = 8;
            this.lbl_itemid.Text = "itemid";
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Location = new System.Drawing.Point(75, 215);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(99, 20);
            this.lbl_itemqty.TabIndex = 9;
            this.lbl_itemqty.Text = "item quantity";
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Location = new System.Drawing.Point(87, 270);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(77, 20);
            this.lbl_itemprice.TabIndex = 10;
            this.lbl_itemprice.Text = "item price";
            // 
            // lbl_deliveryadd
            // 
            this.lbl_deliveryadd.AutoSize = true;
            this.lbl_deliveryadd.Location = new System.Drawing.Point(91, 345);
            this.lbl_deliveryadd.Name = "lbl_deliveryadd";
            this.lbl_deliveryadd.Size = new System.Drawing.Size(120, 20);
            this.lbl_deliveryadd.TabIndex = 11;
            this.lbl_deliveryadd.Text = "deliveryAddress";
            // 
            // cmb_city
            // 
            this.cmb_city.FormattingEnabled = true;
            this.cmb_city.Location = new System.Drawing.Point(796, 58);
            this.cmb_city.Name = "cmb_city";
            this.cmb_city.Size = new System.Drawing.Size(121, 28);
            this.cmb_city.TabIndex = 12;
           // this.cmb_city.SelectedIndexChanged += new System.EventHandler(this.cmb_city_SelectedIndexChanged);
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(600, 66);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(73, 20);
            this.lbl_city.TabIndex = 13;
            this.lbl_city.Text = "order city";
            // 
            // lbl_paymentoption
            // 
            this.lbl_paymentoption.AutoSize = true;
            this.lbl_paymentoption.Location = new System.Drawing.Point(665, 255);
            this.lbl_paymentoption.Name = "lbl_paymentoption";
            this.lbl_paymentoption.Size = new System.Drawing.Size(128, 20);
            this.lbl_paymentoption.TabIndex = 14;
            this.lbl_paymentoption.Text = "payment method";
            // 
            // rdb_online
            // 
            this.rdb_online.AutoSize = true;
            this.rdb_online.Location = new System.Drawing.Point(853, 226);
            this.rdb_online.Name = "rdb_online";
            this.rdb_online.Size = new System.Drawing.Size(76, 24);
            this.rdb_online.TabIndex = 15;
            this.rdb_online.TabStop = true;
            this.rdb_online.Text = "online";
            this.rdb_online.UseVisualStyleBackColor = true;
            // 
            // rdb_cash
            // 
            this.rdb_cash.AutoSize = true;
            this.rdb_cash.Location = new System.Drawing.Point(853, 271);
            this.rdb_cash.Name = "rdb_cash";
            this.rdb_cash.Size = new System.Drawing.Size(68, 24);
            this.rdb_cash.TabIndex = 16;
            this.rdb_cash.TabStop = true;
            this.rdb_cash.Text = "cash";
            this.rdb_cash.UseVisualStyleBackColor = true;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Location = new System.Drawing.Point(540, 429);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(143, 43);
            this.btn_placeorder.TabIndex = 17;
            this.btn_placeorder.Text = "place Order";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 764);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.rdb_cash);
            this.Controls.Add(this.rdb_online);
            this.Controls.Add(this.lbl_paymentoption);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.cmb_city);
            this.Controls.Add(this.lbl_deliveryadd);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.lbl_custname);
            this.Controls.Add(this.lbl_orderid);
            this.Controls.Add(this.txt_deliveryadd);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.txt_custname);
            this.Controls.Add(this.txt_orderid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.TextBox txt_custname;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.TextBox txt_deliveryadd;
        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_custname;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.Label lbl_deliveryadd;
        private System.Windows.Forms.ComboBox cmb_city;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_paymentoption;
        private System.Windows.Forms.RadioButton rdb_online;
        private System.Windows.Forms.RadioButton rdb_cash;
        private System.Windows.Forms.Button btn_placeorder;
    }
}

