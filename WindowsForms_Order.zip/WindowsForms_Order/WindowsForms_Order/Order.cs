﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms_Order
{
    class Order
    {
        private int Orderid;
        private string CustName;
        private int Itemid;
        private int Itemqty;
        private int itemprice;
        private string Deliveryaddress;
        private string city;
        private string method;
       public Order(int Orderid, string CustName, int Itemid, int Itemqty, int itemprice, string Deliveryaddress,string city,string method)
        {
            this.Orderid = Orderid;
            this.CustName = CustName;
            this.Itemid = Itemid;
            this.Itemqty = Itemqty;
            this.itemprice = itemprice;
            this.Deliveryaddress = Deliveryaddress;            
            this.city = city;
            this.method = method;


        }

        public int GetOrderValue()
        {
            int value = this.itemprice * this.Itemqty;
            return value;
        }


        
          
    }
}
