create table tbl_cust(id int identity(100,1),name varchar(100),password varchar(100))

alter proc p_cust(@name varchar(100),@password varchar(100))
as
insert tbl_cust values(@name,@password)
return @@identity
