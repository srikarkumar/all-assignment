create database Emp_DB
use Emp_DB


create table Employees(employeeid int,employeefname varchar(100),employeelname varchar(100),employeecity varchar(100),employeedob date,employeesalary int,employeestatus varchar(100))
alter table employees add employeeDept varchar(100),employeeDoj date;


select * from Employees

insert Employees values(1001,'srikar','kumar','hyd','07-08-1998',30000,'working','testing','10-10-1999')
insert Employees values(1002,'ram','kumar','mdr','06-07-1995',40000,'working','dev','12-10-2000')
insert Employees values(1003,'laxman','kumari','bng','12-08-2014',25000,'notworking','testing','10-30-2001')
insert Employees values(1004,'vin','bor','chennai','06-07-1991',60000,'working','dev','2-10-2015')
insert Employees values(1005,'suchi','kumari','pune','06-30-1995',15000,'notworking','network','10-8-2014')
insert Employees values(1061,'sridhr','kumar','hyd','12-08-1998',30000,'working','testing','2-5-2017')
insert Employees values(1007,'ram','kumar','mdr','06-01-1995',40000,'working','network','10-7-2015')
insert Employees values(1008,'lvee','kumar','bng','12-04-2014',25000,'notworking','network','12-10-1999')
insert Employees values(1009,'venkat','brot','chennai','10-30-1991',60000,'working','datascience','10-12-2015')
insert Employees values(1010,'bhum','kumari','pune','06-10-1997',15000,'notworking','network','10-15-1999')

select * from Employees where employeecity='chennai'

select *from Employees where employeesalary between 25000 and 50000

select employeefname+employeelname as 'fullname',employeeid,employeecity from Employees

select * from Employees order by len(employeefname) asc

select sum(employeesalary) from Employees

select count(employeeid) from Employees

select * from Employees where DATEPART(mm,employeeDoj)=2 --feb

select * ,datediff(YY,employeeDoj,getdate()) from Employees where datediff(YY,employeeDoj,getdate())>5

select employeeDept,COUNT(employeeDept) from Employees group by employeeDept

select employeecity,COUNT(employeecity) from Employees group by employeecity

update Employees set employeecity='pune' where employeecity='chennai' 

select employeedept,sum(employeesalary) from employees group by employeeDept having sum(employeesalary)>50000

select *,round(employeesalary,4) from Employees

update Employees set employeestatus='resigned' where employeestatus='working' 

select * from Employees where DATEPART(mm,employeeDoj)=GETDATE()




update Employees set employeeDoj='10-18-2018' where employeeDoj='2-10-2015'




















