﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Win_serialization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            product p = b.Deserialize (fs) as product;
            fs.Close();
            txtid.Text = p.productid.ToString();
            txtname.Text = p.productname;
            txtprice.Text = p.productprice.ToString();
        }

        private void btnser_Click(object sender, EventArgs e)
        {
            product p = new product();
            p.productid = Convert.ToInt32(txtid.Text);
            p.productname = txtname.Text;
            p.productprice = Convert.ToInt32(txtprice.Text);

            FileStream fs = new FileStream("c:/test/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("ser done");

        }

        private void btnxml_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/prod.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            product p = new product();
            p.productid = Convert.ToInt32(txtid.Text);
            p.productname = txtname.Text;
            p.productprice = Convert.ToInt32(txtprice.Text);

            XmlSerializer xml = new XmlSerializer(typeof(product));
            xml.Serialize(fs, p);
            MessageBox.Show("xml ser done");

        }

        private void btndexml_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/prod.xml", FileMode.Open, FileAccess.Read);
            XmlSerializer xml = new XmlSerializer(typeof(product));
            product p = xml.Deserialize(fs) as product;
            fs.Close();
            txtid.Text = p.productid.ToString();
            txtname.Text = p.productname;
            txtprice.Text = p.productprice.ToString();

        }
    }
}
