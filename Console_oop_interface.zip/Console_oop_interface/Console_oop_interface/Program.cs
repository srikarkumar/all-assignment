﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_interface
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductA obj1 = new ProductA(1000, "dotnet");
            ProductB obj2 = new ProductB(2222, "book");

            Transport t = new Transport();
            t.Send(obj1);
            t.Send(obj2);

            Console.ReadLine(); 
        }
    }
}
