﻿namespace Win_student
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtmailid = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtid = new System.Windows.Forms.TextBox();
            this.lblmailid = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnfind = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtmailid
            // 
            this.txtmailid.Location = new System.Drawing.Point(206, 337);
            this.txtmailid.Name = "txtmailid";
            this.txtmailid.Size = new System.Drawing.Size(197, 26);
            this.txtmailid.TabIndex = 19;
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(206, 250);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(197, 26);
            this.txtaddress.TabIndex = 18;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(206, 175);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(197, 26);
            this.txtcity.TabIndex = 17;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(206, 110);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(197, 26);
            this.txtname.TabIndex = 16;
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(206, 42);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(197, 26);
            this.txtid.TabIndex = 15;
            // 
            // lblmailid
            // 
            this.lblmailid.AutoSize = true;
            this.lblmailid.Location = new System.Drawing.Point(59, 340);
            this.lblmailid.Name = "lblmailid";
            this.lblmailid.Size = new System.Drawing.Size(107, 20);
            this.lblmailid.TabIndex = 14;
            this.lblmailid.Text = "student mailid";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(63, 256);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbladdress.Size = new System.Drawing.Size(124, 20);
            this.lbladdress.TabIndex = 13;
            this.lbladdress.Text = "student address";
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Location = new System.Drawing.Point(59, 178);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(90, 20);
            this.lblcity.TabIndex = 12;
            this.lblcity.Text = "student city";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(59, 110);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(107, 20);
            this.lblname.TabIndex = 11;
            this.lblname.Text = "student name";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(59, 45);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(79, 20);
            this.lblid.TabIndex = 10;
            this.lblid.Text = "student id";
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(623, 294);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(147, 69);
            this.btndelete.TabIndex = 21;
            this.btndelete.Text = "delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(623, 56);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(159, 61);
            this.btnupdate.TabIndex = 20;
            this.btnupdate.Text = "update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnfind
            // 
            this.btnfind.Location = new System.Drawing.Point(623, 175);
            this.btnfind.Name = "btnfind";
            this.btnfind.Size = new System.Drawing.Size(147, 69);
            this.btnfind.TabIndex = 22;
            this.btnfind.Text = "find";
            this.btnfind.UseVisualStyleBackColor = true;
            this.btnfind.Click += new System.EventHandler(this.btnfind_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 404);
            this.Controls.Add(this.btnfind);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.txtmailid);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.lblmailid);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblid);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtmailid;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.Label lblmailid;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnfind;
    }
}