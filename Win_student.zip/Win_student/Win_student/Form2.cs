﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_student
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if (txtname.Text == string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if (txtcity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txtaddress.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txtmailid.Text == string.Empty)
            {
                MessageBox.Show("enter milid");
            }
            else
            {
                string name = txtname.Text;
                string city = txtcity.Text;
                string address = txtaddress.Text;
                string mailid = txtmailid.Text;

                studentdal dal = new studentdal();
                bool status = dal.updatestudent(name, city, address, mailid);
                if (status) { MessageBox.Show("updated"); }
                else { MessageBox.Show("not found"); }


            }
        }

        private void btnfind_Click(object sender, EventArgs e)
        {
            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(txtid.Text);
                studentdal dal = new studentdal();
                student s = dal.findstudent(id);
                if (s != null)
                {
                    txtname.Text = s.studentname;
                    txtcity.Text = s.studentcity;
                    txtaddress.Text = s.studentaddress;
                    txtmailid.Text = s.studentmailid;

                }
                else
                {
                    MessageBox.Show("not found");
                }

            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(txtid.Text);

                studentdal dal = new studentdal();
                bool status = dal.Delete(id);
                if (status) { MessageBox.Show("deleted"); }
                else { MessageBox.Show("not valid"); }
            }
        }
    }
    }
