﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_student
{
    class studentdal
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["const"].ConnectionString);

        public int addstudent(student s)
        {
            SqlCommand com_student_insert = new SqlCommand
            ("insert tbl_student values(@name, @city, @address, @mailid)",con);

            com_student_insert.Parameters.AddWithValue("@name", s.studentname);
            com_student_insert.Parameters.AddWithValue("@city", s.studentcity);
            com_student_insert.Parameters.AddWithValue("@address", s.studentaddress);
            com_student_insert.Parameters.AddWithValue("@mailid", s.studentmailid);

            con.Open();
            com_student_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int id = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return id;
        }

        public student findstudent(int id)
        {
            SqlCommand com_find = new SqlCommand("select * from tbl_student where studentid=@id", con);
            com_find.Parameters.AddWithValue("@id", id);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                student s = new student();
                s.studentid = dr.GetInt32(0);
                s.studentname = dr.GetString(1);
                s.studentcity = dr.GetString(2);
                s.studentaddress= dr.GetString(3);
                s.studentmailid = dr.GetString(4);
                
                con.Close();
                return s;
            }
            else
            {
                return null;
            }
        }

        public bool updatestudent(string name,string city,string address,string mailid)
        {
            SqlCommand com_update = new SqlCommand
                ("update tbl_student set studentname=@name,studentcity=@city,studentaddress=@address,studentmailid=@mailid",con);

            com_update.Parameters.AddWithValue("@name", name);
            com_update.Parameters.AddWithValue("@city", city);
            com_update.Parameters.AddWithValue("@address", address);
            com_update.Parameters.AddWithValue("@mailid", mailid);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            if (count > 0)
            {
                return true;
            }
            else { return false; }
        }

        public bool Delete(int id)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_customer where empid=@id", con);
            com_delete.Parameters.AddWithValue("@id", id);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();

            if (count > 0) { return true; }
            else { return false; }

        }


    }
}
