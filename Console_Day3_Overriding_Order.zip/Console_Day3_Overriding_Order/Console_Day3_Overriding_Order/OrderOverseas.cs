﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Overriding_Order
{
    class OrderOverseas:Order
    {
        public OrderOverseas(string CustomerName,int ItemQuantity,int ItemPrice):base(CustomerName,ItemQuantity,ItemPrice)
        {

        }
        public override int GetOrderValue()
        {
            int amount = (PItemPrice * PItemQuantity);
            int total = amount+(amount / 10);
            return total;
        }
    }
}
