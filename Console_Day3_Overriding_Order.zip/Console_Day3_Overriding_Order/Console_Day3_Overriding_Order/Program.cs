﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Overriding_Order
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter Customer name:");
            string cname = Console.ReadLine();
            Console.WriteLine("enter item Quantity");
            int qty = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item price");
            int price = Convert.ToInt32(Console.ReadLine());

            Order obj = null;
            Console.WriteLine("enter customer type");
            string type = Console.ReadLine();

            if (type == "Order")
            {
                obj = new Order(cname, qty, price);
            }
            else if (type == "overseas")
            {
                obj = new OrderOverseas(cname, qty, price);
            }
            if(obj!=null)
            { 
            int orderval = obj.GetOrderValue();
            Console.WriteLine("ordervalue is:" + orderval);

            int id = obj.POrderId;
            Console.WriteLine("Ordere id is:" + id); }


            Console.ReadLine();
                

        }
    }
}
