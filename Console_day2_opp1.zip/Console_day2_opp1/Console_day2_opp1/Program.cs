﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_opp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter acc Id:");
            int AccId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter cust name:");
            string Name = Console.ReadLine();
            Console.WriteLine("enter acc balance");
            int Balance = Convert.ToInt32(Console.ReadLine());

            Account obj = new Account(AccId, Name, Balance);

            int NewBalance = obj.GetBalance();
            Console.WriteLine("acc Balance" + NewBalance);

            Console.WriteLine("enter an amt to withdraw");
            int amount = Convert.ToInt32(Console.ReadLine());
            obj.Withdraw(amount);

            NewBalance = obj.GetBalance();
            Console.WriteLine("Acc Balance" + NewBalance);

            Console.WriteLine("enter amt to deposite:");
            amount = Convert.ToInt32(Console.ReadLine());
            obj.Deposite(amount);

            NewBalance = obj.GetBalance();
            Console.WriteLine("Acc Balance" + NewBalance);






            /*  Console.WriteLine("enter Customer name:");
              string name = Console.ReadLine();
              Console.WriteLine("enter Customer Id:");
              int Id = Convert.ToInt32(Console.ReadLine());
              Console.WriteLine("enter Customer city:");
              string city =Console.ReadLine();

              Customer obj = new Customer(name, Id, city);

              string details = obj.GetDetails();
              Console.WriteLine(details);*/
            Console.ReadLine();
        
        }
    }
}
