select * from tbl_customers
--1
create proc p_addcust(@name varchar(100),@password varchar(100),@city varchar(100),@address varchar(100),@mobile varchar(100),@mailid varchar(100))
as
insert tbl_customers values(@name,@password,@city,@address,@mobile,@mailid)
return @@identity
--2
create proc p_find(@id int)
as
select * from tbl_customers where custid=@id
--3
create proc p_update(@id int,@name varchar(100),@password varchar(100),@city varchar(100),@address varchar(100),@mobile varchar(100),@mailid varchar(100))
as
update tbl_customers set custname=@name,custpassword=@password,custcity=@city,custadd=@address,custmobile=@mobile,custmailid=@mailid where custid=@id;
return @@rowcount
--4
create proc p_search(@key varchar(100))
as
select * from tbl_customers where custid like'%'+@key+'%'or custname like'%'+@key+'%'or custcity like'%'+@key+'%'
--5
alter proc p_delete(@id int)
as
delete  tbl_customers where custid=@id
return @@rowcount
--6
alter proc p_logincust(@id varchar(100),@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_customers where custid=@id and custpassword=@password
return @count






