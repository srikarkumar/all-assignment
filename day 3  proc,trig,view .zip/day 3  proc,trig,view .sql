

declare @count int=0;
 set @count=100;
 select @count;


 select @count=count(*) from tbl_employees

 if (@count>0)
begin 
--insert
end 
else 
begin 
--update
end
select @count;

declare @count int=0
while(@count<10)
begin
select @count;
set @count=@count+1;
end

alter proc sp_employees
as
 select * from tbl_employees order by employeesalary desc

 exec sp_employees
 

 create proc sp_employees_city(@city varchar(100))
 as
 select * from tbl_employees where employeecity=@city


 create proc sp_add_acc1(@name varchar(100),@balance int)
 as
 if(@balance>1000)
 begin
 insert tbl_accounts values(@name,@balance)
 return @@identity
 end
 else
  begin
  return 0
  end
 
  declare @r int
  exec @r=sp_add_acc1 'srikar',10000
  select @r

 create proc sp_acc_blc(@accountid int)
 as 
 declare @balance int
 select @balance=accbalance from tbl_accounts where accountid=@accountid
 return @balance
 
 declare @blc int 
 exec @blc=sp_acc_blc 1000
 select @blc


 select * from tbl_custometinfo

 create proc sp_login(@id int,@password varchar(100))
 as
 declare @count int
 select @count=count(*) from tbl_custometinfo
 where customerid=@id and  customerpassword=@password
 return @count



 select * from tbl_employees

 create proc sp_employeedetails(@id int,@name varchar(100) output,@city varchar(100) output)
 as
 select @name=employeename,@city=employeecity from tbl_employees where employeeid=@id

 declare @ename varchar(100)
 declare @ecity varchar(100)
 exec sp_employeedetails 10,@ename output,@ecity output
 select @ename,@ecity

  ---trigger

 create table tbl_students
 (
 
 studentid int,
 studentname  varchar(100),
 )
 
alter trigger trg_add_student
 on tbl_students
 for insert 
 as 
 begin
 select * from inserted
 select 'trigger fired'
  end

  insert tbl_students values(111,'ssss')
  select * from tbl_students



  create table stack(
  
  itemid int primary key,
  itemqty int
  )
  insert stack values(2,100)
  select * from stack

  create table orders(
  orderid int,
  itemid int not null foreign key references stack(itemid),
  itemqty int not null,
  itemprice int check(itemprice>0)
  )

  insert orders values(6,1,30,200)
  select * from orders

  create trigger tg_order 
  on orders
  for insert
  as
  begin 
  declare @itemid  int
  declare @itemqty int
  select @itemid=itemid,@itemqty=itemqty from inserted
  update stack set itemqty=itemqty-@itemqty where itemid=@itemid
end

---views
select * from tbl_employees 

alter view v_employee_hyd
with encryption
as 
select employeeid,employeename,employeesalary from dbo.tbl_employees where employeecity='hyd'
with check option

sp_helptext v_employee_hyd

select * from v_employee_hyd
insert v_employee_hyd values(101,'srjikar','hyd',100000)



create table t1(code int,name varchar(100) )
insert t1 values(1,'a')
select * from t1

create table t2(code int,city varchar (100))
insert t2 values(1,'bng')


create view v_data
as
select t1.code,t1.name,t2.city from t1 join t2 on t1.code=t2.code

create trigger trg_data
on v_data
instead of insert
as
begin
declare @code int
declare @name varchar(100)
declare @city varchar(100)
select @code=code,@name=name,@city=city from inserted
insert t1 values(@code,@name)
insert t2 values(@code,@city)
end

insert v_data values(2,'kkk','fff')

select * from v_data


create table tbl_empinfo
(empid int identity(10,1),
empname varchar(100),
empcity varchar(100)
)

declare @c int=0;
while(@c<50000)
begin
insert tbl_empinfo values('ddd','hyd')
set @c=@c+1;
end


select * from tbl_empinfo where empid=49999

create clustered index idx
on tbl_empinfo(empid)

select * from tbl_employees
begin tran tr1
insert tbl_employees values(100110,'acg','fcd',20000)
select * from tbl_employees
commit tran

rollback tran

--1
create proc p_emp
as
insert tbl_employees values(10110,'acg','fcd',20000)
exec p_emp
select * from tbl_employees
--2
create proc p1_emp
as
update tbl_employees set employeename='ramu' where employeeid=1009
exec p1_emp
select * from tbl_employees
--3
create proc p111_cus(@customerid int,@customerpassword varchar(100),@customermobile varchar(100))
as
 
 update tbl_custometinfo set customermobile=@customermobile
  where customerpassword= @customerpassword and customerid=@customerid

 exec p111_cus 100,'abc11def','123456789123'
select * from tbl_custometinfo
--4
create proc sp_c1(@customerid int)
as
select tbl_custometinfo.customerid,tbl_custometinfo.customername,
tbl_accountinfo.accountid,tbl_accountinfo.accountbalance
 from tbl_custometinfo join tbl_accountinfo 
 on tbl_custometinfo.customerid=tbl_accountinfo.customerid
 where tbl_custometinfo.customerid=@customerid
  
declare @customer int
 exec sp_c1 105
 --5
 select * from tbl_accountinfo
 select * from tbl_transactioninfo

 sp_helptrigger tbl_transactioninfo
 drop trigger tg111_acc

 alter trigger trg_acc on tbl_transactioninfo
 for insert
 as
 declare @id int
 declare @amount int
 declare @transactiontype varchar(100)
 select @transactiontype=transactiontype,@amount=amount,@id=accountid from tbl_transactioninfo
  if(@transactiontype='with')
 begin
  update tbl_accountinfo set accountbalance=accountbalance-@amount 
 end
  else if(@transactiontype='dep')
 begin
update tbl_accountinfo set accountbalance=accountbalance+@amount 
 end
 insert tbl_transactioninfo values(10000,'with',100,'10-10-2018')

 --6
 create view v_11
 as
 select tbl_custometinfo.customerid,tbl_custometinfo.customername,
 tbl_accountinfo.accountid,tbl_accountinfo.accountbalance
 from tbl_custometinfo join tbl_accountinfo
 on tbl_custometinfo.customerid=tbl_accountinfo.customerid

 select * from v_11

 --7
 select * from tbl_custometinfo

 create proc check1(@id varchar(100),@password varchar(100))
 as
 select customerid,customerpassword from tbl_custometinfo
 if (@id=customerid && @password=customerpassword)
 begin
 return 1
 end
 else
 begin 
 return 0
 end






























