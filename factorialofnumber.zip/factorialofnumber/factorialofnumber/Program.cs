﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factorialofnumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j=1,n;
            Console.WriteLine("enter number");
            n=Convert.ToInt32(Console.ReadLine());

            for (i = 1; i <= n; i++)
            {
                j = j * i;                   
            }
            Console.WriteLine(j);
            Console.ReadLine();

        }
    }
}
