﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee e = new Employee(100, "srikar", "hyd", 30000, "madhapur", "dotnet project", 2, 12345, "sbi", 23);

            HR h = new HR();
            h.GetEmp(e);

            Manager m = new Manager();
            m.GetEmp(e);

            Account a = new Account();
            a.GetEmp(e);


            Console.ReadLine();

        }
    }
}
