﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_Employee
{
    interface IHREmp
    {
         string GetEmployeeAddres();

        int GetEmployeeSalary();

         int GetEmployeeId();
            
    }
}
