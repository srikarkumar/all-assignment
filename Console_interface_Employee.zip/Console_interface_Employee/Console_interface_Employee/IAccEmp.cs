﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_Employee
{
    interface IAccEmp
    {
        int GetEmployeeSalary();

        int GetEmployeeAccNo();

        int GetEmployeeId();
    }
}
