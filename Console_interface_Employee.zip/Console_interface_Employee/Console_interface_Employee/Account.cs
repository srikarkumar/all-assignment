﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_Employee
{
    class Account
    {
        public void GetEmp(IAccEmp obj1)
        {
            int salary = obj1.GetEmployeeSalary();
            int accno = obj1.GetEmployeeAccNo();
            int eid = obj1.GetEmployeeId();

            Console.WriteLine("emp salary:" + salary);
            Console.WriteLine("emp acc no:" + accno);
            Console.WriteLine("emp id:" + eid);
        }
    }
}
