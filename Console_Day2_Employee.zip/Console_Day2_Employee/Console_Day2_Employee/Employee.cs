﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Employee
{
    class Employee
    {
        private int EmployeeId;
        private string EmployeeName;
        private string EmployeeCity;
        private double EmployeeSalary;

        public Employee(int EmployeeId,string EmployeeName,string EmployeeCity,double EmployeeSalary)
        {
            this.EmployeeId = EmployeeId;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;
        }

        public double GetEmployeeSalary(int days)
        {
           double MonthlySalary= (this.EmployeeSalary/30) * days;
            return MonthlySalary;   
        }
        public string GetDetails()
        {
            return this.EmployeeId+ " " + this.EmployeeName + " " + this.EmployeeCity;
        }
    }
}
