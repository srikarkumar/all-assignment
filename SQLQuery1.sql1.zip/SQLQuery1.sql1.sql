create table tbl_accounts
(accountid int identity(1000,1),customername varchar(100),accbalance int)

insert tbl_accounts values('john',20000)
insert tbl_accounts values('sri',30000)
insert tbl_accounts values('ddd',40000)
insert tbl_accounts values('jessy',10000)

select @@IDENTITY --returns recent id created

select * from tbl_accounts