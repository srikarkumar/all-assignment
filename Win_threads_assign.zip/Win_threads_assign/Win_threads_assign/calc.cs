﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Win_threads_assign
{
    class calc
    {
        public Task<double> getcalc(double d1, double d2, string opttype)
        {
            Task<double> t = Task.Run(() =>
              {
                  System.Threading.Thread.Sleep(3000);
                  if (opttype == "+")
                  {
                      return d1 + d2;
                  }
                  else if (opttype == "-")
                  {
                      return d1 - d2;

                  }
                  else
                  {
                      throw new Exception("invalid operation");
                  }
              });

            return t;
        }
    }
}
