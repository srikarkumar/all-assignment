﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_linq
{
    class order
    {
        public int ordrid  {get; set;}
        public int customerid { get; set; }
        public string itemname { get; set; }
        public int itemprice { get; set; }
    }
}
