﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Bank_prac.Controllers
{
    public class bankexpController : Controller
    {
       public ActionResult newuser()
        {
            return View();
        }
        [HttpPost]
        public ActionResult newuser(string mailid, string password, string fullname)
        {
            if (mailid == "srikar" && password == "123" && fullname == "srikarkumar")
            {
                return RedirectToAction("login", "bankexp");
                    }
            else
            {
                ViewBag.msg = "invalid details";
                return View();
            }
        }
        public ActionResult login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult login(string mailid,string password)
        {
            if (mailid == "srikar" && password == "123")
            {
              string mailid = Session["mailid"].ToString();
                return RedirectToAction("index", "bankexp");
            }
            else
            {
                ViewBag.msg = "invalid mailid or password";
                return View();
            }
        }
        public ActionResult index()
        {
            return View();
        }

    }
}