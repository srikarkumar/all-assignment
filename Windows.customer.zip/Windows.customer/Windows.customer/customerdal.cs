﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Windows.customer
{
    class customerdal
    {
        SqlConnection conn = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constri"].ConnectionString);


        public int addcustomer(customer c)
        {
            try
            {
                SqlCommand com_cust_insert = new SqlCommand("p_addcust", conn);


                com_cust_insert.Parameters.AddWithValue("@name", c.custname);
                com_cust_insert.Parameters.AddWithValue("@password", c.custpassword);
                com_cust_insert.Parameters.AddWithValue("@city", c.custcity);
                com_cust_insert.Parameters.AddWithValue("@address", c.custadd);
                com_cust_insert.Parameters.AddWithValue("@mobile", c.custmobile);
                com_cust_insert.Parameters.AddWithValue("@mailid", c.custmailid);
                com_cust_insert.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_cust_insert.Parameters.Add(retdata);

                conn.Open();
                com_cust_insert.ExecuteNonQuery();
                conn.Close();

                int id = Convert.ToInt32(retdata.Value);
                return id;
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("finally");
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        public customer findcustomer(int id)
        {
            try {
                SqlCommand com_find = new SqlCommand("p_find", conn);
                com_find.Parameters.AddWithValue("@id", id);
                com_find.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader dr1 = com_find.ExecuteReader();
                if (dr1.Read())
                {
                    customer c = new customer();
                    c.custname = dr1.GetString(1);
                    c.custpassword = dr1.GetString(2);
                    c.custcity = dr1.GetString(3);
                    c.custadd = dr1.GetString(4);
                    c.custmobile = dr1.GetString(5);
                    c.custmailid = dr1.GetString(6);

                    return c;
                }
                else { return null; }
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("finally");
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        public bool update(int id, string add, string mobile)
        {
            try {
                SqlCommand com_update = new SqlCommand("p_update", conn);

                com_update.Parameters.AddWithValue("@id", id);
                com_update.Parameters.AddWithValue("@add", add);
                com_update.Parameters.AddWithValue("@mobile", mobile);
                com_update.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_update.Parameters.Add(retdata);

                conn.Open();
                com_update.ExecuteNonQuery();
                conn.Close();
                int count = Convert.ToInt32(retdata);
                if (count > 0) { return true; }
                else { return false; }
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("finally");
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public bool Delete(int id)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("p_delete", conn);
                com_delete.Parameters.AddWithValue("@id", id);
                com_delete.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_delete.Parameters.Add(retdata);

                conn.Open();
                com_delete.ExecuteNonQuery();
                conn.Close();
                int count = Convert.ToInt32(com_delete.ExecuteNonQuery());

                if (count > 0) { return true; }
                else { return false; }
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("finally");
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        public List<customer>searchcust(string search)
        {
            try
            {
                SqlCommand com_search = new SqlCommand("p_search", conn);
                com_search.Parameters.AddWithValue("@key", search);
                com_search.CommandType = CommandType.StoredProcedure;

                conn.Open();
                SqlDataReader dr = com_search.ExecuteReader();
                List<customer> cumlist = new List<customer>();
                while (dr.Read())
                {
                    customer obj = new customer();
                    obj.custid = dr.GetInt32(0);
                    obj.custname = dr.GetString(1);
                    obj.custpassword = dr.GetString(2);
                    obj.custcity = dr.GetString(3);
                    obj.custadd = dr.GetString(4);
                    obj.custmobile = dr.GetString(5);
                    obj.custmailid = dr.GetString(6);
                    cumlist.Add(obj);
                }
                conn.Close();
                return cumlist;
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("finally");
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }


        }
        public bool login(string id, string password)
        {
            try { 

            SqlCommand com_login = new SqlCommand("p_logincust", conn);
            com_login.Parameters.AddWithValue("@id", id);
            com_login.Parameters.AddWithValue("@password", password);

            com_login.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_login.Parameters.Add(retdata);

            conn.Open();
            com_login.ExecuteNonQuery();
            conn.Close();
            int count = Convert.ToInt32(com_login.ExecuteNonQuery());
            if (count > 0) { return true; }
            else { return false; }
            }
        finally
            {
                System.Windows.Forms.MessageBox.Show("finally");
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
        

    }
}
