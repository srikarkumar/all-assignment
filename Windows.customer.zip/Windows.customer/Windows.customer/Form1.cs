﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows.customer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtname.Text == string.Empty)
                {
                    MessageBox.Show("enter name");
                }
                else if (txtpassword.Text == string.Empty)
                {
                    MessageBox.Show("enter password");
                }
                else if (txtcity.Text == string.Empty)
                {
                    MessageBox.Show("enter city");
                }
                else if (txtadd.Text == string.Empty)
                {
                    MessageBox.Show("enter address");
                }
                else if (txtmobile.Text == string.Empty)
                {
                    MessageBox.Show("enter mobile no");
                }
                else if (txtmailid.Text == string.Empty)
                {
                    MessageBox.Show("enter mail id");
                }

                else
                {
                    string name = txtname.Text;
                    string password = txtpassword.Text;
                    string city = txtcity.Text;
                    string add = txtadd.Text;
                    string mobile = txtmobile.Text;
                    string mailid = txtmailid.Text;

                    customer obj = new customer();
                    obj.custname = name;
                    obj.custcity = city;
                    obj.custpassword = password;
                    obj.custadd = add;
                    obj.custmobile = mobile;
                    obj.custmailid = mailid;

                    customerdal dal = new customerdal();
                    int id = dal.addcustomer(obj);
                    MessageBox.Show("customer added:" + id);
                }
            }
            catch (System.Data.SqlClient.SqlException exp)
            {
                MessageBox.Show("sql error : " + exp.Message);
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            finally { MessageBox.Show("finally block"); }

        }

        private void btnfind_Click(object sender, EventArgs e)
        {

            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(txtid.Text);
                customerdal dal = new customerdal();
                customer c = dal.findcustomer(id);
                if (c != null)
                {
                    txtname.Text = c.custname;
                    txtcity.Text = c.custcity;
                    txtpassword.Text = c.custpassword;
                    txtadd.Text = c.custadd;
                    txtmobile.Text = c.custmobile;
                    txtmailid.Text = c.custmailid;
                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if (txtadd.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txtmobile.Text == string.Empty)
            {
                MessageBox.Show("enter mobile no");
            }


            else
            {
                int id = Convert.ToInt32(txtid.Text);
                string add = txtadd.Text;
                string mobile = txtmobile.Text;

                customer obj = new customer();
                obj.custid = id;
                obj.custadd = add;
                obj.custmobile = mobile;


                customerdal dal = new customerdal();
                bool status = dal.update(id, add, mobile);
                if (status) { MessageBox.Show("updated"); }
                else { MessageBox.Show("not found"); }
            }
        }

        private void btndalete_Click(object sender, EventArgs e)
        {
            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(txtid.Text);

               customerdal dal = new customerdal();
                bool status = dal.Delete(id);
                if (status) { MessageBox.Show("deleted"); }
                else { MessageBox.Show("not valid"); }
            }
        }
    }
}