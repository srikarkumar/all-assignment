﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prct2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 4, 5, 3, 8, 7 ,2};
            int m=arr[0];
            int n = arr[0];
            for (int i = 1; i < arr.Length; i++)
            {
                if (m < arr[i])
                {
                    m = arr[i];
                }
                if(n>arr[i])
                {
                    n = arr[i];
                }
            }
            Console.WriteLine("max value"+" "+m);
            Console.WriteLine("min value" + " " + n);



            Console.ReadLine();
        }
    }
}
