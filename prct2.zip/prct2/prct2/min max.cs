﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prct2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 4, 5, 3, 8, 7, 2 };
            int m = arr[0];
            int n = arr[0];
            int x = 0;
            int y = 0;
            int temp = 0;
            for (int i = 1; i < arr.Length; i++)
            {
                if (m < arr[i])
                {
                    m = arr[i];
                    x = i;
                }
            }
            for (int j = 1; j < arr.Length; j++) { 
                if (n > arr[j])
                {
                    n = arr[j];
                    y = j;
                }
        }
            Console.WriteLine("min and max are:" + y + " "+x);

         temp = 0;
         temp=x;
            x = y;
            y = temp;
            Console.WriteLine("after replacing:" + y + " " + x);

        
            Console.ReadLine();
        }
    }
}
