﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_Abstract_Account
{
   abstract class Account
    {
        protected int AccId;
        protected string CustomerName;
        protected int AccBalance;

        public Account(int AccId,string CustomerName,int AccBalance)
        {
            this.AccId = AccId;
            this.CustomerName = CustomerName;
            this.AccBalance = AccBalance;
            Console.WriteLine("acc constructor");
        }
        public int PAccId { get { return this.AccId; } }
        public string PCustomerName { get { return this.CustomerName; } }
        public int PAccBalance { get { return this.AccBalance; } } 

        public void StopPayment()
        {
            Console.WriteLine("stop payment called");
        }
        public void BlockAcc()
        {
            Console.WriteLine("block acc");
        }
        public int GetBalance()
        {
            return this.AccBalance;
        }
        public abstract void Deposite(int amt);
        public abstract void Withdraw(int amt);

    }
}
