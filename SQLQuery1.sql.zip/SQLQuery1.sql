use PathfrontDB

create table tbl_ordersasp(orderid int identity(100,1) primary key,customermailid varchar(100),productid int,productprice int,productqty int,paymenttype varchar(100),ordercity varchar(100),deliveryaddress varchar(100))

select * from tbl_ordersasp
drop table tbl_ordersasp
alter proc p_order(@mailid varchar(100) ,@pid int,@pprice int,@pqty int,@type varchar(100),@city varchar(100),@address varchar(100))
as
insert tbl_ordersasp values(@mailid,@pid,@pprice,@pqty,@type,@city,@address)
return @@identity









