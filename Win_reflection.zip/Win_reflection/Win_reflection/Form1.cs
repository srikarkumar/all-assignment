﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace Win_reflection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnreadtype_Click(object sender, EventArgs e)
        {
            //test obj = new test();
            //Type t = obj.GetType();
            Type t = typeof(test);
            MessageBox.Show(t.FullName);
            MessageBox.Show(t.Assembly.FullName);
            foreach(MethodInfo m in t.GetMethods())
            {
                MessageBox.Show(m.Name);
            }
        }
        Assembly asm;
        private void btnloadassembly_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.ShowDialog();
            string dlladdress = dialog.FileName;
            asm = Assembly.LoadFile(dlladdress);
            MessageBox.Show(asm.FullName);
            lstclasses.Items.Clear();
            foreach(Type t in asm.GetTypes())
            {
                lstclasses.Items.Add(t.FullName);
            }
        }

        private void lstclasses_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = lstclasses.Text;
            Type t = asm.GetType(name);
            lstmethods.Items.Clear();
            foreach(MethodInfo m in t.GetMethods())
            {
                lstmethods.Items.Add(m.Name);
            }
        }

        private void btncall_Click(object sender, EventArgs e)
        {
            Type t = asm.GetType(lstclasses.Text);
            object obj = Activator.CreateInstance(t);
            MethodInfo m = t.GetMethod(lstmethods.Text);
            object returndata = m.Invoke(obj, null);
            MessageBox.Show(returndata.ToString());

        }
    }
}
