﻿namespace Win_reflection
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnreadtype = new System.Windows.Forms.Button();
            this.btnloadassembly = new System.Windows.Forms.Button();
            this.lstclasses = new System.Windows.Forms.ListBox();
            this.lstmethods = new System.Windows.Forms.ListBox();
            this.btncall = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnreadtype
            // 
            this.btnreadtype.Location = new System.Drawing.Point(12, 12);
            this.btnreadtype.Name = "btnreadtype";
            this.btnreadtype.Size = new System.Drawing.Size(132, 42);
            this.btnreadtype.TabIndex = 0;
            this.btnreadtype.Text = "Read Type";
            this.btnreadtype.UseVisualStyleBackColor = true;
            this.btnreadtype.Click += new System.EventHandler(this.btnreadtype_Click);
            // 
            // btnloadassembly
            // 
            this.btnloadassembly.Location = new System.Drawing.Point(191, 12);
            this.btnloadassembly.Name = "btnloadassembly";
            this.btnloadassembly.Size = new System.Drawing.Size(132, 42);
            this.btnloadassembly.TabIndex = 1;
            this.btnloadassembly.Text = "load assembly";
            this.btnloadassembly.UseVisualStyleBackColor = true;
            this.btnloadassembly.Click += new System.EventHandler(this.btnloadassembly_Click);
            // 
            // lstclasses
            // 
            this.lstclasses.FormattingEnabled = true;
            this.lstclasses.ItemHeight = 20;
            this.lstclasses.Location = new System.Drawing.Point(12, 94);
            this.lstclasses.Name = "lstclasses";
            this.lstclasses.Size = new System.Drawing.Size(292, 184);
            this.lstclasses.TabIndex = 2;
            this.lstclasses.SelectedIndexChanged += new System.EventHandler(this.lstclasses_SelectedIndexChanged);
            // 
            // lstmethods
            // 
            this.lstmethods.FormattingEnabled = true;
            this.lstmethods.ItemHeight = 20;
            this.lstmethods.Location = new System.Drawing.Point(370, 94);
            this.lstmethods.Name = "lstmethods";
            this.lstmethods.Size = new System.Drawing.Size(296, 184);
            this.lstmethods.TabIndex = 3;
            // 
            // btncall
            // 
            this.btncall.Location = new System.Drawing.Point(700, 298);
            this.btncall.Name = "btncall";
            this.btncall.Size = new System.Drawing.Size(132, 42);
            this.btncall.TabIndex = 4;
            this.btncall.Text = "call";
            this.btncall.UseVisualStyleBackColor = true;
            this.btncall.Click += new System.EventHandler(this.btncall_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 393);
            this.Controls.Add(this.btncall);
            this.Controls.Add(this.lstmethods);
            this.Controls.Add(this.lstclasses);
            this.Controls.Add(this.btnloadassembly);
            this.Controls.Add(this.btnreadtype);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnreadtype;
        private System.Windows.Forms.Button btnloadassembly;
        private System.Windows.Forms.ListBox lstclasses;
        private System.Windows.Forms.ListBox lstmethods;
        private System.Windows.Forms.Button btncall;
    }
}

