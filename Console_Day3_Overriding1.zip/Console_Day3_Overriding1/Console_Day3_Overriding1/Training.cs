﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Overriding1
{
    class Training:Employee
    {
        public Training(int EmployeeId,string EmployeeName,int EmployeeSalary):base(EmployeeId,EmployeeName,EmployeeSalary)
        {

        }
        public override int GetSalary(int days)
        {
            return 10000;
        }

    }
}
