﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Overriding1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter emp id");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter emp name");
            string name = Console.ReadLine();
            Console.WriteLine("enter emp salary");
            int salary = Convert.ToInt32(Console.ReadLine());

            Employee obj = null;

            Console.WriteLine("enter emp type");
            string type=Console.ReadLine();

            if (type == "employee")
            {

                obj = new Employee(id, name, salary);
            }
            else if (type == "contract")
            {
                obj = new Employee_Contract(id, name, salary);
            }
            else if(type =="Training")
            {
                obj = new Training(id, name, salary);
            }
           

            if (obj != null)
            {

                string work = obj.GetWork();
                Console.WriteLine(work);

               

                Console.WriteLine("enter days");
                int Days = Convert.ToInt32(Console.ReadLine());
                int CurrentMonthSalary = obj.GetSalary(Days);
                Console.WriteLine("salary" + CurrentMonthSalary);
            }
            Console.ReadLine();
        }
    }
}
