﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc.first.application.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            int loginid = Convert.ToInt32(Session["loginid"]);
            ViewBag.loginid = loginid;
            return View();
        }
       public ActionResult calc()
        {
            return View(); //calc  ("calc")
        }
        [HttpPost]
        public ActionResult calc(int num1, int num2)
        {
            int total = num1 + num2;
            ViewBag.sum = total;
            return View();

        }
        [HttpPost]
        public ActionResult Getsubtract(int num1, int num2)
        {
            int total = num1 - num2;
            ViewBag.sum = total;
            return View("calc");
        }
        public ActionResult login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult login(int loginid,string password)
        {
            if(loginid==1001 && password == "123")
            {
                Session["loginid"] = loginid;
                return RedirectToAction("Index", "Home");
               
            }
            else
            {
                ViewBag.msg = "invalid userid or password";
                return View();
            }
        }
        

    }
}