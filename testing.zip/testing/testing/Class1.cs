﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testing
{
    public class Class1
    {
        public string call()
        {
            return "srikar";
        }
        public string call2()
        {
            return "kumar";
        }
        
             
        }
    }

