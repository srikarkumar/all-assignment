﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day1_basics2
{
    class Program
    {
        static void Main(string[] args)
        {
            bool flag = true;
            while(flag)
            {
                Console.WriteLine(flag);
                flag = false;
            }

            /*int[] arr = new int[5];

            arr[0] = 1;
            arr[1] = 2;
            arr[2] = 3;
            arr[3] = 4;
            arr[4] = 5;
    for(int c=0;c<arr.Length;c++)
            {
                Console.WriteLine(arr[c]);
            }

    foreach(int n in arr){
                Console.WriteLine(n);
            }
    */
            /*int opt = 3;
            switch(opt)
            {
             case 1:
            Console.WriteLine("one");
            break;
        case 2:
            Console.WriteLine("two");
            break;
        case 3:
            Console.WriteLine("three");
            break;

            }*/





           /* Console.WriteLine("enter item name:");
            string itemname = Console.ReadLine();
            Console.WriteLine("enter quantity");
            int quan = Convert.ToInt32(Console.ReadLine());

            if(quan==5)
            {
                Console.WriteLine("invalid qty");
            }
            else if(quan>5)
            {
                Console.WriteLine("order plcd");
            }
            else
            {
                Console.WriteLine("placd");
            }
            int i = 1;
            while(i<10)
            {
                Console.WriteLine(i);
                i++;
            }*/

            Console.ReadLine();
        }
    }
}
