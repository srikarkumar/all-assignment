﻿namespace Win_io
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbinarywriter = new System.Windows.Forms.Button();
            this.btnbinaryreader = new System.Windows.Forms.Button();
            this.btnstreamreader = new System.Windows.Forms.Button();
            this.btnstreamwriter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnbinarywriter
            // 
            this.btnbinarywriter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbinarywriter.Location = new System.Drawing.Point(102, 73);
            this.btnbinarywriter.Name = "btnbinarywriter";
            this.btnbinarywriter.Size = new System.Drawing.Size(144, 57);
            this.btnbinarywriter.TabIndex = 0;
            this.btnbinarywriter.Text = "binary writer";
            this.btnbinarywriter.UseVisualStyleBackColor = true;
            this.btnbinarywriter.Click += new System.EventHandler(this.btnbinarywriter_Click);
            // 
            // btnbinaryreader
            // 
            this.btnbinaryreader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbinaryreader.Location = new System.Drawing.Point(102, 202);
            this.btnbinaryreader.Name = "btnbinaryreader";
            this.btnbinaryreader.Size = new System.Drawing.Size(148, 62);
            this.btnbinaryreader.TabIndex = 1;
            this.btnbinaryreader.Text = "binary reader";
            this.btnbinaryreader.UseVisualStyleBackColor = true;
            this.btnbinaryreader.Click += new System.EventHandler(this.btnbinaryreader_Click);
            // 
            // btnstreamreader
            // 
            this.btnstreamreader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstreamreader.Location = new System.Drawing.Point(413, 202);
            this.btnstreamreader.Name = "btnstreamreader";
            this.btnstreamreader.Size = new System.Drawing.Size(213, 62);
            this.btnstreamreader.TabIndex = 3;
            this.btnstreamreader.Text = "stream reader";
            this.btnstreamreader.UseVisualStyleBackColor = true;
            this.btnstreamreader.Click += new System.EventHandler(this.btnstreamreader_Click);
            // 
            // btnstreamwriter
            // 
            this.btnstreamwriter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstreamwriter.Location = new System.Drawing.Point(413, 73);
            this.btnstreamwriter.Name = "btnstreamwriter";
            this.btnstreamwriter.Size = new System.Drawing.Size(213, 57);
            this.btnstreamwriter.TabIndex = 2;
            this.btnstreamwriter.Text = "stream writer";
            this.btnstreamwriter.UseVisualStyleBackColor = true;
            this.btnstreamwriter.Click += new System.EventHandler(this.btnstreamwriter_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 353);
            this.Controls.Add(this.btnstreamreader);
            this.Controls.Add(this.btnstreamwriter);
            this.Controls.Add(this.btnbinaryreader);
            this.Controls.Add(this.btnbinarywriter);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnbinarywriter;
        private System.Windows.Forms.Button btnbinaryreader;
        private System.Windows.Forms.Button btnstreamreader;
        private System.Windows.Forms.Button btnstreamwriter;
    }
}

