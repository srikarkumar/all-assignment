﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Day5_first_application
{
    public partial class frm_control : Form
    {
        public frm_control()
        {
            InitializeComponent();
        }

        private void frm_control_Load(object sender, EventArgs e)
        {
            lst_cities.Items.Add("pune");
            lst_cities.Items.Add("hyd");
            lst_cities.Items.Add("bng");
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (rdb_male.Checked == false && rdb_female.Checked == false)
            {
                MessageBox.Show("Select gender");
            }
            else
            {
                string gender = string.Empty;
                if (rdb_male.Checked)
                {
                    gender = "male";
                }
                else
                {
                    gender = "female";
                }
                MessageBox.Show(gender);
            }







            bool status =chk_readme.Checked ;
            if (status)
            {
                MessageBox.Show("it is checked");
            }
            else
            {

                MessageBox.Show("not checked");
            }

            if (lst_cities.Text == string.Empty)
            {
                MessageBox.Show("select city");
            }
            else
            {
                string city = lst_cities.Text;
                MessageBox.Show(city);
            }
        }

        private void rdb_male_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lst_cities_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
