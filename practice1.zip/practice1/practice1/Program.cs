﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter two numbers");
            int n1 =Convert.ToInt32(Console.ReadLine());
            int n2 = Convert.ToInt32(Console.ReadLine());
            int result;


            if (n1 == n2)
            {
                result = (n1 + n2) * 3;
            }
            else
            {
                result = n1 + n2;
            }
            Console.WriteLine(result);
            Console.ReadLine();

        }
        
    }
}
