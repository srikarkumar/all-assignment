﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collection
{
    class Student
    {
        public delegate void delleave(int id, string Reason);
        public event delleave evtleave;



        private int StudentId;
        private string StudentName;
        private string StudentCity;
        public static int count = 200;
        public Student(string StudentName,string StudentCity)
        {
            Student.count++;
            this.StudentId = Student.count; ;
            this.StudentName = StudentName;
            this.StudentCity = StudentCity;
        }

        public int PStudentId { get { return this.StudentId; } }
        public string PStudentName { get { return this.StudentName; } }
        public string PStudentCity { get { return this.StudentCity; } }

        public void TakeLeave(string Reason)
        {
            if (this.evtleave != null)
            {
                this.evtleave(this.StudentId, Reason);
            }

            Console.WriteLine("student on leave:" + this.StudentId + ", reason :" + Reason);
        }
    }
}
