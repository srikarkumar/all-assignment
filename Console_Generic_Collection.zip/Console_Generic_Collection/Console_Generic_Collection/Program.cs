﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            College c = new College(1,"pathfront");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("enter ur no. 1:add  2:find  3:remove  4:show  5:exit  6:leave");
                    int Opt = Convert.ToInt32(Console.ReadLine());
                switch (Opt)
                {
                    case 1:
                        Console.WriteLine("enter student name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("enter student city:");
                        string city = Console.ReadLine();
                        Student s = new Student(name, city);
                        c.AddStudent(s);
                        Console.WriteLine("studentid:" + s.PStudentId);
                        break;
                    case 2:
                        Console.WriteLine("enter stud id");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Student obj = c.Find(id);
                        if (obj != null)
                        {
                            Console.WriteLine(obj.PStudentId+" "+obj.PStudentName);

                        }
                        else
                        {
                            Console.WriteLine("student not found:");
                        }
                        break;
                    case 3:
                        Console.WriteLine("enter student id");
                        int sid = Convert.ToInt32(Console.ReadLine());
                        bool Status = c.Remove(sid);
                        if (Status)
                        {
                            Console.WriteLine("student removed:");
                        }
                        else { Console.WriteLine("student not found"); }
                        break;
                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        Console.WriteLine("enter stud id:");
                        int sidd = Convert.ToInt32(Console.ReadLine());
                        Student sobj = c.Find(sidd);
                        Console.WriteLine("enter reason :");
                        string Reason = Console.ReadLine();
                        sobj.TakeLeave(Reason);

                        break;



                }
            }

        }
    }
}
