﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collection
{
    class College
    {
        public void onleave(int id,string Reason)
        {
            Console.WriteLine("college class:stud on leave:" + id + " " + Reason);
        }


        private int CollegeId;
        private string CollegeName;

        public College(int CollegeId,string CollegeName)
        {
            this.CollegeId = CollegeId;
            this.CollegeName = CollegeName;
        }
        private List<Student> StudentList = new List<Student>();

        public void AddStudent(Student st)
        {
            Student.delleave d = new Student.delleave(this.onleave);
            st.evtleave += d;
            StudentList.Add(st);
        }
        public Student Find(int Id)
        {
            foreach(Student s in StudentList)
            {
                if (s.PStudentId == Id)
                {
                    return s;
                }
            }
            return null;
        }
        public bool Remove(int ID)
        {
            foreach(Student s in StudentList)
            {
                if (s.PStudentId == ID)
                {
                    StudentList.Remove(s);
                    return true;
                }
            }
            return false;
        }
        public void ShowAll()
        {
            foreach(Student s in StudentList)
            {
                Console.WriteLine(s.PStudentId + " " + s.PStudentName + " " + s.PStudentCity);
            }
        }

    }
}
