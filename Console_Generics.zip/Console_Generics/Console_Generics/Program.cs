﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> marks = new List<int>();
            marks.Add(45);
            marks.Add(33);
            int m = marks[0];


            foreach(int n in marks)
            {
                Console.WriteLine(n);
            }
            Dictionary<int, string> nameswithkeys = new Dictionary<int, string>();
            nameswithkeys.Add(1000, "ssssa");
            nameswithkeys.Add(1222, "fvvhb");

            string s1 = nameswithkeys[1000];
            Console.WriteLine(s1);

            nameswithkeys.Contains < 1000 >//for checking key is there r not


            Test t = new Test();
            int x = t.GetDetails<int>(2000);
            string str = t.GetDetails<string>("sss");

            Console.WriteLine(x);
            Console.WriteLine(str);
            Console.ReadLine();
        }
    }
}
