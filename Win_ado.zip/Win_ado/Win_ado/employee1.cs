﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_ado
{
    class employee1
    {
        public int empid { get; set; }
        public string empname { get; set; }
        public string empcity { get; set; }
        public string emppassword { get; set; }
        public DateTime empdoj { get; set; }
         
    }
}
