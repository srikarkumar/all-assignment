﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration; //dll ref

namespace Win_ado
{
    class employeedal1
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int Addemployee(employee1 emp)
        {
            SqlCommand com_emp_insert = new SqlCommand
                ("insert tbl_employees1 values(@name,@city,@password,getdate())", con);

            com_emp_insert.Parameters.AddWithValue("@name", emp.empname);
            com_emp_insert.Parameters.AddWithValue("@city", emp.empcity);
            com_emp_insert.Parameters.AddWithValue("@password", emp.emppassword);
            con.Open();
            com_emp_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int id = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return id;
                     
        }
        public employee1 find(int id)
        {
            SqlCommand com_find = new SqlCommand("select * from tbl_employees1 where empid=@id",con);
            com_find.Parameters.AddWithValue("@id", id);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                employee1 e = new employee1();
                e.empid = dr.GetInt32(0);
                e.empname = dr.GetString(1);
                e.empcity = dr.GetString(2);
                e.emppassword = dr.GetString(3);
                e.empdoj = dr.GetDateTime(4);
                con.Close();
                return e;
            }
            else
            {
                return null;
            }
        }
        
        public bool update(int id,string city,string password)
        {
            SqlCommand com_update = new SqlCommand
                ("update tbl_employees1 set empcity=@city,emppassword=@password where empid=@id", con);

            com_update.Parameters.AddWithValue("@id", id);
            com_update.Parameters.AddWithValue("@city", city);
            com_update.Parameters.AddWithValue("@password", password);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else { return false; }

        }

        public bool Delete(int id)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_employees1 where empid=@id", con);
                com_delete.Parameters.AddWithValue("@id", id);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();

            if (count > 0) { return true; }
            else { return false; }

        }
        public List<employee1> showemployees(string city)
        {
            SqlCommand com_employees = new SqlCommand
                ("select * from tbl_employees1 where empcity=@city", con);
            com_employees.Parameters.AddWithValue("@city", city);
            con.Open();
            SqlDataReader dr = com_employees.ExecuteReader();
            List<employee1> emplist = new List<employee1>();
            while (dr.Read())
            {
                employee1 obj = new employee1();
                obj.empid = dr.GetInt32(0);
                obj.empname = dr.GetString(1);
                obj.empcity = dr.GetString(2);
                obj.emppassword = dr.GetString(3);
                obj.empdoj = dr.GetDateTime(4);
                emplist.Add(obj);

            }
            con.Close();
            return emplist;


        }
        public List<employee1> searchemployees(string search)
        {
            SqlCommand com_search = new SqlCommand("select * from tbl_employees1 where empid like '%"+search+"%'or empname like'%"+search+"%' or empcity like '%"+search+"%'", con);

            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<employee1> emplist = new List<employee1>();
            while (dr.Read())
            {
                employee1 obj = new employee1();
                obj.empid = dr.GetInt32(0);
                obj.empname = dr.GetString(1);
                obj.empcity = dr.GetString(2);
                obj.emppassword = dr.GetString(3);
                obj.empdoj = dr.GetDateTime(4);
                emplist.Add(obj);

            }
            con.Close();
            return emplist;

        }

        public bool login(string id,string password)
        {
            SqlCommand com_login = new SqlCommand("select count(*) from tbl_employees1 where empid=@id and emppassword=@password", con);

            com_login.Parameters.AddWithValue("@id", id);
            com_login.Parameters.AddWithValue("@password", password);
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0) { return true; }
            else { return false; }

        }



        public bool logininjection(string id, string password)
        {
            SqlCommand com_login = new SqlCommand("select count(*) from tbl_employees1 where empid='"+id+"' and emppassword='"+password+"'", con);

            
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0) { return true; }
            else { return false; }

        }
    }
}
