﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class Frm_find : Form
    {
        public Frm_find()
        {
            InitializeComponent();
        }

        private void Frm_find_Load(object sender, EventArgs e)
        {

        }

        private void btnfind_Click(object sender, EventArgs e)
        {
            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(txtid.Text);
                employee1DAL dal = new employee1DAL();
                employee1 emp = dal.find(id);
                if (emp != null)
                {
                    txtname.Text = emp.empname;
                    txtcity.Text = emp.empcity;
                    txtpassword.Text = emp.emppassword;
                    txtempdoj.Text = emp.empdoj.ToString();
                }
                else
                {
                    MessageBox.Show("not found");
                }
            }

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");

            }
            else if (txtcity.Text == string.Empty)
            {
                MessageBox.Show("enter city");

            }
            else if (txtpassword.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else {
                int id = Convert.ToInt32(txtid.Text);
                string city = txtcity.Text;
                string password = txtpassword.Text;

                employee1DAL dal = new employee1DAL();
                bool status =dal.update(id, city, password);
                if (status) { MessageBox.Show("updated"); }
                else { MessageBox.Show("not found"); }


            }

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int id = Convert.ToInt32(txtid.Text);

                employee1DAL dal = new employee1DAL();
                bool status = dal.Delete(id);
                if (status) { MessageBox.Show("deleted"); }
                else { MessageBox.Show("not valid"); }
            }
        }
    }
}
