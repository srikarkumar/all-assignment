﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uniquecharsinstring
{
    class Program
    {
        static void Main(string[] args)
        {
            bool dup=false;
            Console.WriteLine("enter string");
            string str = Console.ReadLine();

            foreach(var x in str)
            {
                for(int i = 1; i < str.Length; i++)
                {
                    if (x == str[i])
                    {
                        dup = true;
                    }
                }
            }
            if (dup == true)
            {
                Console.WriteLine("string has repeated chars");
            }
            else
            {
                Console.WriteLine("unique chars string");
            }
            Console.ReadLine();



        }
    }
}
