﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Console_mutex_semaphore
{
    class Program
    {
        static void Main(string[] args)
        {
           bool status;
            //Mutex m = new Mutex(false, "xyz", out status);
            Semaphore sm = new Semaphore(4, 4);
            Task t1 = Task.Run(() =>
            {
                //  m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("task1 started");
                Thread.Sleep(10000);
                Console.WriteLine("task1 completed");
                //m.ReleaseMutex();
                sm.Release();
            });
            Task t2 = Task.Run(() =>
            {
                sm.WaitOne();
                //m.WaitOne();
                Console.WriteLine("task2 started");
                Thread.Sleep(10000);
                Console.WriteLine("task2 completed");
                // m.ReleaseMutex();
                sm.Release();
            });
            Task t3 = Task.Run(() =>
            {
                sm.WaitOne();
                //m.WaitOne();
                Console.WriteLine("task3 started");
                Thread.Sleep(10000);
                Console.WriteLine("task3 completed");
                // m.ReleaseMutex();
                sm.Release();
            });
            Task t4 = Task.Run(() =>
            {
                sm.WaitOne();
                //m.WaitOne();
                Console.WriteLine("task4 started");
                Thread.Sleep(10000);
                Console.WriteLine("task4 completed");
                // m.ReleaseMutex();
                sm.Release();
            });


            Console.ReadLine();
        }
        
    }
}
