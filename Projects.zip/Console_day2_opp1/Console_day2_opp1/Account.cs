﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_opp1
{
    class Account
    {
        private int AccountId;
        private string CustomerName;
        private int AccountBalance;

        public Account(int AccountId,string CustomerName,int AccountBalance) :this()
        {
            this.AccountId = AccountId;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;

            Console.WriteLine("constructor called with parameters:");
        }
        public Account()
        {
            Console.WriteLine("constructor called");
        }
        public void Withdraw(int amount)
        {
            this.AccountBalance = this.AccountBalance - amount;
        }
        public void Deposite(int amount)
        {
            this.AccountBalance = this.AccountBalance + amount;
        }
        public int GetBalance()
        {
            return this.AccountBalance;
        }
    }
}
