﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_opp1
{
    class Customer
    {
        private string CustomerName;
        private int CustomerId;
        private string CustomerCity;
        
        public Customer(string CustomerName,int CustomerId,string Customercity)
        {
            this.CustomerName = CustomerName;
            this.CustomerId = CustomerId;
            this.CustomerCity = CustomerCity;
        }
        public string GetDetails()
        {
            return this.CustomerName + " " + this.CustomerId + " " + this.CustomerCity;
        }
    }
}
