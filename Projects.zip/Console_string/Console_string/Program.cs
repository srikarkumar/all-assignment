﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_string
{
    class Program
    {
        static void Main(string[] args)
        {
            string s1 = "a";
            char[] c = { 'a' };
            object obj = new string(c);

            Console.WriteLine(s1 == obj);
            Console.WriteLine(s1.Equals(obj));

            Console.ReadLine();
        }
    }
}
