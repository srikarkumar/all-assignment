﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_student
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if (txtid.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
           else if (txtname.Text == string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if (txtcity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txtaddress.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if (txtmailid.Text == string.Empty)
            {
                MessageBox.Show("enter milid");
            }
            else
            {
                string name = txtname.Text;
                string city = txtcity.Text;
                string address = txtaddress.Text;
                string mailid = txtmailid.Text;
                student obj = new student();
                obj.studentname = name;
                obj.studentcity = city;
                obj.studentaddress = address;
                obj.studentmailid = mailid;

                studentdal dal = new studentdal();
                int id = dal.addstudent(obj);
                MessageBox.Show("student added:" + id);
            }
        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtid.Text = string.Empty;
            txtname.Text = string.Empty;
            txtmailid.Text = string.Empty;
            txtcity.Text = string.Empty;
            txtaddress.Text = string.Empty;

        }
    }
}
