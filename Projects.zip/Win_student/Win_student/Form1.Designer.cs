﻿namespace Win_student
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblid = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblmailid = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtmailid = new System.Windows.Forms.TextBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(55, 51);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(79, 20);
            this.lblid.TabIndex = 0;
            this.lblid.Text = "student id";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(55, 119);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(107, 20);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "student name";
            this.lblname.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Location = new System.Drawing.Point(55, 184);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(90, 20);
            this.lblcity.TabIndex = 2;
            this.lblcity.Text = "student city";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(25, 262);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbladdress.Size = new System.Drawing.Size(124, 20);
            this.lbladdress.TabIndex = 3;
            this.lbladdress.Text = "student address";
            // 
            // lblmailid
            // 
            this.lblmailid.AutoSize = true;
            this.lblmailid.Location = new System.Drawing.Point(55, 352);
            this.lblmailid.Name = "lblmailid";
            this.lblmailid.Size = new System.Drawing.Size(107, 20);
            this.lblmailid.TabIndex = 4;
            this.lblmailid.Text = "student mailid";
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(187, 48);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(197, 26);
            this.txtid.TabIndex = 5;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(187, 116);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(197, 26);
            this.txtname.TabIndex = 6;
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(187, 262);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(197, 26);
            this.txtaddress.TabIndex = 8;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(187, 184);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(197, 26);
            this.txtcity.TabIndex = 7;
            // 
            // txtmailid
            // 
            this.txtmailid.Location = new System.Drawing.Point(187, 349);
            this.txtmailid.Name = "txtmailid";
            this.txtmailid.Size = new System.Drawing.Size(197, 26);
            this.txtmailid.TabIndex = 9;
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(556, 119);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(159, 61);
            this.btnadd.TabIndex = 10;
            this.btnadd.Text = "add new";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnreset
            // 
            this.btnreset.Location = new System.Drawing.Point(568, 252);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(147, 69);
            this.btnreset.TabIndex = 11;
            this.btnreset.Text = "reset";
            this.btnreset.UseVisualStyleBackColor = true;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(847, 481);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.txtmailid);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.lblmailid);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblmailid;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtmailid;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnreset;
    }
}

