﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_Employee
{
    class Manager
    {
        public void GetEmp(IManagerEmp obj2)
        {
            int eid = obj2.GetEmployeeId();
            int exp = obj2.GetEmployeeExp();
            string prjdt = obj2.GetEmployeeProjectDetails();

            Console.WriteLine("emp id"+eid);
            Console.WriteLine("emp experiance "+exp);
            Console.WriteLine("emp project details are:"+prjdt);

        }
    }
}
