﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_Employee
{
    class HR
    {
        public void GetEmp(IHREmp obj)
        {
            string address = obj.GetEmployeeAddres();
            int salary = obj.GetEmployeeSalary();
            int eid = obj.GetEmployeeId();

            Console.WriteLine("emp address" + address);
            Console.WriteLine("emp salary" + salary);
            Console.WriteLine("emp id" + eid);
        }
    }
}
