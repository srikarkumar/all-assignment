﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_Employee
{
    class Employee:IHREmp,IAccEmp,IManagerEmp
    {
        private int EmployeeId;
        private string EmployeeName;
        private string EmployeeCity;
        private int EmployeeSalary;
        private string EmployeeAddress;
        private string EmployeeProjectDetails;
        private int EmployeeExp;
        private int EmployeeAccountNo;
        private string EmployeeBankName;
        private int EmployeeAge;

        public Employee(int EmployeeId,string EmployeeName, string EmployeeCity, int EmployeeSalary, 
            string EmployeeAddress, string EmployeeProjectDetails, int EmployeeExp, int EmployeeAccountNo,
            string EmployeeBankName, int EmployeeAge)
        {
            this.EmployeeId = EmployeeId;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeProjectDetails = EmployeeProjectDetails;
            this.EmployeeExp = EmployeeExp;
            this.EmployeeAccountNo = EmployeeAccountNo;
            this.EmployeeBankName = EmployeeBankName;
            this.EmployeeAge = EmployeeAge;
        }

       
        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }
        public int GetEmployeeId()
        {
            return this.EmployeeId;
        }
        public int GetEmployeeAccNo()
        {
            return this.EmployeeAccountNo;
        }
        public int GetEmployeeExp()
        {
            return this.EmployeeExp;
        }
        public string GetEmployeeProjectDetails()
        {
            return this.EmployeeProjectDetails;
        }

        public string GetEmployeeAddres()
        {
            return this.EmployeeAddress;
        }
    }
}
