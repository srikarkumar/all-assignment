﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Console_linq_xml
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement orders = new XElement("orders",
         new XElement("orders",
                new XElement("orderid", "1001"),
                new XElement("customername", "srikar"),
                new XElement("orderamount", "2000")),
            new XElement("orders",
                new XElement("orderid", "1002"),
                new XElement("customername", "kumar"),
                new XElement("orderamount", "3000"))
                );
            orders.Save(@"C:\xml/orders.xml");
            Console.WriteLine("XML file created");




            /*
            string url = @"c:\users\prabhas\documents\visual studio 2015\Projects\Console_linq_xml\Console_linq_xml\customers.xml";

            XDocument doc = XDocument.Load(url);
            var data = from x in doc.Descendants("customer")
                       select new
                       {
                           cid = x.Element("customerid").Value,
                           cname=x.Element("customername").Value,
                           ccity=x.Element("customercity").Value
                       };
            foreach(var d in data)
            {
                Console.WriteLine(d.cid + " " + d.cname + " " + d.ccity);
            } */

            Console.ReadLine();
        }
    }
}
