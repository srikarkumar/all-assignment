﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary_practice
{
    public class calculator
    {
        public int sum(int num1,int num2)
        {
            int result = 0;
            return result = num1 + num2;
        }
        public int multiply(int num1, int num2)
        {
            int result = 0;
            return result = num1 * num2;
        }
        public int divide(int num1, int num2)
        {
            int result = 0;
            return result = num1 / num2;
        }
        public int subtract(int num1, int num2)
        {
            int result = 0;
            return result = num1 - num2;
        }



    }
}
