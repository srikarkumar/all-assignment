﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            //entering employee details
            Console.WriteLine("enter EmployeeId");
            int EmployeeId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter EmployeeName:");
            string EmployeeName = Console.ReadLine();
            Console.WriteLine("enter Employee City:");
            string EmployeeCity = Console.ReadLine();
            Console.WriteLine("enter EmployeeSalary");
            int EmployeeSalary = Convert.ToInt32(Console.ReadLine());

            Employee obj = new Employee(EmployeeId,EmployeeName,EmployeeCity,EmployeeSalary);

            //for no of days
            Console.WriteLine("enter no of days:");
            int days=Convert.ToInt32(Console.ReadLine());
            
            // calling monthly salary function
            double MonthlySalary= obj.GetEmployeeSalary(days);
            Console.WriteLine("Employeemonthly salary is :" + MonthlySalary);

            string str = obj.GetDetails();
            Console.WriteLine("details are :" + str);

            Console.ReadLine();
        }
    }
}
