﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_CallByVal_CallByRef
{
    class Test
    {
        public void call(ref int Amt)
        {
            Console.WriteLine("Amt");
        }
        public void CallArray(params int [] marks)
        {
            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }
        }
        //default parameter
        public int GetOrderValue(int ItemPrice,int ItemQty=1)
        {
            return ItemQty * ItemPrice;
        }

    }
}
