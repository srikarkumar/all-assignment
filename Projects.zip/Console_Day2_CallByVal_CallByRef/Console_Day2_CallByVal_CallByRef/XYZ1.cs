﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_CallByVal_CallByRef
{
    partial class XYZ
    {
        public void call() { }
    }
}
