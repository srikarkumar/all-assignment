﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_CallByVal_CallByRef
{
    class Program
    {
        static void Main(string[] args)
        {
            XYZ obj1 = new XYZ();
            obj1.call();
            obj1.GetData();

            int[] marks = new int[3];
            marks[0] = 10;
            marks[1] = 20;
            marks[2] = 30;


            Test obj = new Test();
            obj.CallArray(10,40,60);

            int OrderAmt = obj.GetOrderValue(1000,2);
            Console.WriteLine(OrderAmt);
            //named parameter
            int OrderAmt1 = obj.GetOrderValue(ItemQty:2,ItemPrice:1200);
            Console.WriteLine(OrderAmt1);

            int x=100;
            obj.call(ref x);
            Console.WriteLine(x);
            Console.ReadLine();
        }
    }
}
