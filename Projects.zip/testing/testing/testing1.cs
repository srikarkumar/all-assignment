﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testing
{
   public class testing1
    {
        public string call3()
        {
            return "pathfront";
        }
        public string call4()
        {
            return ".net training";
        }
    }
}
