﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace primenumberseries
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, count=0;
            Console.WriteLine("enter number :");
       int n=Convert.ToInt32(Console.ReadLine());

            for (i = 1; i <= n; i++)
            {
                if (n % i == 0)
                    count++;
            }
            if (count == 2)
            {
                Console.WriteLine(n + " "+"is prime number");
            }
            else
            {
                Console.WriteLine(n + " "+"not prime");
            }

            Console.ReadLine();



        }
    }
}
