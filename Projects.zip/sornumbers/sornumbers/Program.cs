﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sornumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] Arr = new int[5] { 8, 10, 2, 6, 3 };
            Array.Sort(Arr);
            foreach(var x in Arr)
            {
                
                Console.WriteLine(x);
            }
            Console.ReadLine();
        }
    }
}
