﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_generic_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company("pathfront", "jpnagar");
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("enter 1:Add emp  2:search emp  3:remove emp  4:showall  5:exit  6:takeleave");
                int o = Convert.ToInt32(Console.ReadLine());

                switch (o)
                {
                    case 1:
                        {
                            Console.WriteLine("enter emp name:");
                            string name=Console.ReadLine();
                            Console.WriteLine("enter emp city");
                            string city = Console.ReadLine();
                            Employee e1 = new Employee(name, city);
                            c.AddEmployee(e1);
                            Console.WriteLine("empid is:" + e1.PEmployeeId);
                           break;
                        }

                    case 2: {
                            Console.WriteLine("enetr emp id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee obj = c.SearchEmployee(id);
                            if (obj != null)
                            {
                                Console.WriteLine(obj.PEmployeeId + " " + obj.PEmployeeName);
                            }
                            else
                            {
                                Console.WriteLine("emp id not found");
                            }                         
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("enetr emp id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee obj = c.SearchEmployee(id);
                            if (obj != null)
                            {
                                c.Remove(id);
                            }
                            else
                            {
                                Console.WriteLine("emp id not found:");
                            }
                            break;
                        }
                    case 4:
                        {
                            c.Show();
                            break;
                        }
                    case 5:
                        {
                            flag = false;
                            break;
                        }
                    case 6:
                        {
                            Console.WriteLine("enter empid");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee obj11 = c.SearchEmployee(id);
                            Console.WriteLine("enter reason:");
                            string s = Console.ReadLine();
                            obj11.onleave(s);
                            break;
                        }

                }


            }
        }
    }
}
