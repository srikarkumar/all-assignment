﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Console_Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList list = new ArrayList();
            list.Add(100);
            list.Add(200);

            int x = 300;
            list.Add(x);

            foreach (int m in list) { Console.WriteLine(list[m]); }

            Console.WriteLine(list.Count);
            list.Remove(100);
            list.Remove(0);
            foreach (int m in list) { Console.WriteLine(list[m]); }

            Console.ReadLine();

        }
    }
}
