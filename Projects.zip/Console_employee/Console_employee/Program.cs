﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_employee
{
    class Program
    {
        static void Main(string[] args)
        {
            List<employee> emplist = new List<employee>();
            emplist.Add(new employee { employeeid = 100, employeename = "srikar", employeesalary = 20000, employeeexp = 5, employeecity = "hyd" });
            emplist.Add(new employee { employeeid = 101, employeename = "kumar", employeesalary = 10000, employeeexp = 3, employeecity = "pune" });
            emplist.Add(new employee { employeeid = 102, employeename = "vinay", employeesalary = 30000, employeeexp = 6, employeecity = "hyd" });
            emplist.Add(new employee { employeeid = 103, employeename = "gopi", employeesalary = 50000, employeeexp = 7, employeecity = "chennai" });
            emplist.Add(new employee { employeeid = 104, employeename = "rahul", employeesalary = 60000, employeeexp = 8, employeecity = "pune" });


            List<employeeleave> leavelist = new List<employeeleave>();
            leavelist.Add(new employeeleave { leaveid = 10, leavetype = "sick", reason = "fever", employeeid = 100 });
            leavelist.Add(new employeeleave { leaveid = 11, leavetype = "casual", reason = "shop", employeeid = 101 });
            leavelist.Add(new employeeleave { leaveid = 12, leavetype = "timepass", reason = "enjoying", employeeid = 103 });
            leavelist.Add(new employeeleave { leaveid = 13, leavetype = "fest", reason = "celebrate", employeeid = 105 });
            leavelist.Add(new employeeleave { leaveid = 14, leavetype = "summer", reason = "swimming", employeeid = 101 });

            // linq 1
            var exp = from e in emplist
                      where e.employeeexp > 5
                        select e;
            foreach(var x in exp)
            {
                Console.WriteLine(x.employeeid + " " + x.employeename + " " + x.employeeexp);
            }
            //lambda 1
            var exp1 = emplist.Where((e) => e.employeeexp > 5);
            foreach (var x in exp1)
            {
                Console.WriteLine(x.employeeid + " " + x.employeename + " " + x.employeeexp);

            }
            //linq 2
            var sal = from e in emplist
                      where e.employeesalary > 50000
                      select e;
            foreach(var x in sal)
            {
                Console.WriteLine(x.employeeid + " " + x.employeename + " " + x.employeeexp + " " + x.employeesalary);
            }

            //lambda 2
            var sal1 = emplist.Where((e) => e.employeesalary > 50000);
            foreach(var x in sal1)
            {
                Console.WriteLine(x.employeeid + " " + x.employeename + " " + x.employeeexp + " " + x.employeesalary);
            }
            // linq 3
            string city = "chennai";
            var emps = from e in emplist
                       where e.employeecity == city
                       select e;
            foreach(var x in emps)
            {
                Console.WriteLine(x.employeeid + " " + x.employeename + " " + x.employeecity);
            }
            //lambda 3
            
            var emp1 = emplist.Where((e) => e.employeecity == city);
            foreach(var x in emp1)
            {
                Console.WriteLine(x.employeeid + " " + x.employeename + " " + x.employeecity);
            }
            //linq 4
            var show = from s in emplist
                       where s.employeename.StartsWith("s")
                       select s;
            foreach(var x in show)
            {
                Console.WriteLine(x.employeeid + " " + x.employeename + " " + x.employeecity);
            }
            //lambda 4
            var show1 = emplist.Where((j) => j.employeename.StartsWith("s"));
            foreach( var x in show1)
            {
                Console.WriteLine(x.employeeid + " " + x.employeename + " " + x.employeecity);
            }

            //lanq
            var joindata = from e in emplist
                           join l in leavelist
         on e.employeeid equals l.employeeid
                           select new { eid = e.employeeid, ename = e.employeename, ecity = e.employeecity, lid = l.leaveid, ltype = l.leavetype, rsn = l.reason };
            foreach(var x in joindata)
            {
                Console.WriteLine(x.eid + " " + x.ename + " " + x.ecity + " " + x.lid + " " + x.ltype + " " + x.rsn);
            }
            //lambda
            var join = emplist.Join(leavelist,
                (e) => e.employeeid,
                (l) => l.employeeid,
                (e, l) => new
                {
                    eid = e.employeeid,
                    ename = e.employeename,
                    ecity = e.employeecity,
                    lid = l.leaveid,
                    ltype = l.leavetype,
                    rsn = l.reason
                });
            foreach(var x in join)
            {
                Console.WriteLine(x.eid + " " + x.ename + " " + x.ecity + " " + x.lid + " " + x.ltype + " " + x.rsn);
            }


            Console.ReadLine();

        }
    }
}
