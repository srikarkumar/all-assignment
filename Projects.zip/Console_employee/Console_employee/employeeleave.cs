﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_employee
{
    class employeeleave
    {
        public int leaveid { get; set; }
        public string leavetype { get; set; }
        public string reason { get; set; }
        public int employeeid { get; set; }

    }
}
