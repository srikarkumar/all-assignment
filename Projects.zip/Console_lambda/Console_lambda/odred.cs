﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_lambda
{
    class odred
    {
        public int ordrid { get; set; }
        public int customerid { get; set; }
        public string itemname { get; set; }
        public int itemprice { get; set; }
    }
}
