﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_oop4_inheritance
{
    class Customer
    {
        protected string CustomerEmailId;
        protected string CustomerName;

        public Customer(string CustomerEmailId,string CustomerName)
        {
            this.CustomerEmailId = CustomerEmailId;
            this.CustomerName = CustomerName;
            Console.WriteLine("customer const");
        }
        public string PCustomerEmailId
        {
            get
            {
                return this.CustomerEmailId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
    }
}
