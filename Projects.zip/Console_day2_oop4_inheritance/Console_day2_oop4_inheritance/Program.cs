﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_oop4_inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter cust email:");
            string Email = Console.ReadLine();
            Console.WriteLine("enter cust name:");
            string Name = Console.ReadLine();

            Console.WriteLine("enter cust type");
            string type = Console.ReadLine();
            if (type == "online")
            {
                Console.WriteLine("enter payment type");
                string pay = Console.ReadLine();
                Console.WriteLine("enter delivery add");
                string add = Console.ReadLine();

                Customer_Online objonline = new Customer_Online(Email, Name, pay, add);
                Console.WriteLine(objonline.PCustomerEmailId + " " + objonline.PCustomerName + " " + objonline.PPaymentType + " " + objonline.PDeliveryAdd);

            }
            else
            {

                Customer obj = new Customer(Email, Name);
                Console.WriteLine(obj.PCustomerEmailId + " " + obj.PCustomerName);

            }


            Console.ReadLine();
        }
    }
}
