﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_oop4_inheritance
{
    // sealed  class Customer_Online:Customer  for no more derived class 
    class Customer_Online :Customer
    {
        private string PaymentType;
        private string DeliveryAdd;

        public Customer_Online(string CustomerEmailId,string CustomerName,string PaymentType,string DeliveryAdd):base(CustomerEmailId,CustomerName)
        {
            this.PaymentType = PaymentType;
            this.DeliveryAdd = DeliveryAdd;
            Console.WriteLine("custmer online const");
        }
        public string PPaymentType
        {
            get
            {
                return this.PaymentType;
            }
        }
        public string PDeliveryAdd
        {
            get
            {
                return this.DeliveryAdd;
            }
        }

    }
}
