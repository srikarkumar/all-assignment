﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Frm_control
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lst_cities.Items.Add("pune");
            lst_cities.Items.Add("hyd");
            lst_cities.Items.Add("bngl");
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (lst_cities.Text == string.Empty)
            {
                MessageBox.Show("select a city");
            }
            else
            {
                string city = lst_cities.Text;
                MessageBox.Show("city");
            }
        }
    }
}
