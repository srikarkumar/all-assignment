﻿namespace Frm_control
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_cities = new System.Windows.Forms.ListBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.cmb_cities = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lst_cities
            // 
            this.lst_cities.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_cities.FormattingEnabled = true;
            this.lst_cities.ItemHeight = 32;
            this.lst_cities.Location = new System.Drawing.Point(36, 12);
            this.lst_cities.Name = "lst_cities";
            this.lst_cities.Size = new System.Drawing.Size(168, 100);
            this.lst_cities.TabIndex = 0;
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Location = new System.Drawing.Point(345, 26);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(136, 47);
            this.btn_save.TabIndex = 1;
            this.btn_save.Text = "save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // cmb_cities
            // 
            this.cmb_cities.FormattingEnabled = true;
            this.cmb_cities.Location = new System.Drawing.Point(151, 205);
            this.cmb_cities.Name = "cmb_cities";
            this.cmb_cities.Size = new System.Drawing.Size(121, 28);
            this.cmb_cities.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 413);
            this.Controls.Add(this.cmb_cities);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.lst_cities);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lst_cities;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.ComboBox cmb_cities;
    }
}

