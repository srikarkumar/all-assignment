﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Day5_first_application
{
    public partial class Frm_sum : Form
    {
        public Frm_sum()
        {
            InitializeComponent();
        }

        private void btn_sum_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter num1");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter num2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                int sum = num1 + num2;
                MessageBox.Show(sum.ToString());
                MessageBox.Show("sum is:" + sum);

            }
            
        }
    }
}
