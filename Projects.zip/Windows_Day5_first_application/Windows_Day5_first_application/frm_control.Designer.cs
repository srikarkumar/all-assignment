﻿namespace Windows_Day5_first_application
{
    partial class frm_control
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_cities = new System.Windows.Forms.ListBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.chk_readme = new System.Windows.Forms.CheckBox();
            this.rdb_male = new System.Windows.Forms.RadioButton();
            this.rdb_female = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lst_cities
            // 
            this.lst_cities.FormattingEnabled = true;
            this.lst_cities.ItemHeight = 20;
            this.lst_cities.Location = new System.Drawing.Point(21, 12);
            this.lst_cities.Name = "lst_cities";
            this.lst_cities.Size = new System.Drawing.Size(163, 44);
            this.lst_cities.TabIndex = 0;
            this.lst_cities.SelectedIndexChanged += new System.EventHandler(this.lst_cities_SelectedIndexChanged);
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(45, 156);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(70, 53);
            this.btn_save.TabIndex = 1;
            this.btn_save.Text = "save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // chk_readme
            // 
            this.chk_readme.AutoSize = true;
            this.chk_readme.Location = new System.Drawing.Point(370, 23);
            this.chk_readme.Name = "chk_readme";
            this.chk_readme.Size = new System.Drawing.Size(89, 24);
            this.chk_readme.TabIndex = 2;
            this.chk_readme.Text = "readme";
            this.chk_readme.UseVisualStyleBackColor = true;
            // 
            // rdb_male
            // 
            this.rdb_male.AutoSize = true;
            this.rdb_male.Location = new System.Drawing.Point(276, 201);
            this.rdb_male.Name = "rdb_male";
            this.rdb_male.Size = new System.Drawing.Size(68, 24);
            this.rdb_male.TabIndex = 3;
            this.rdb_male.TabStop = true;
            this.rdb_male.Text = "male";
            this.rdb_male.UseVisualStyleBackColor = true;
            this.rdb_male.CheckedChanged += new System.EventHandler(this.rdb_male_CheckedChanged);
            // 
            // rdb_female
            // 
            this.rdb_female.AutoSize = true;
            this.rdb_female.Location = new System.Drawing.Point(276, 245);
            this.rdb_female.Name = "rdb_female";
            this.rdb_female.Size = new System.Drawing.Size(82, 24);
            this.rdb_female.TabIndex = 4;
            this.rdb_female.TabStop = true;
            this.rdb_female.Text = "female";
            this.rdb_female.UseVisualStyleBackColor = true;
            // 
            // frm_control
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 340);
            this.Controls.Add(this.rdb_female);
            this.Controls.Add(this.rdb_male);
            this.Controls.Add(this.chk_readme);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.lst_cities);
            this.Name = "frm_control";
            this.Text = "frm_control";
            this.Load += new System.EventHandler(this.frm_control_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_cities;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.CheckBox chk_readme;
        private System.Windows.Forms.RadioButton rdb_male;
        private System.Windows.Forms.RadioButton rdb_female;
    }
}