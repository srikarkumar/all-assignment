﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_Abstract_Account
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter acc Id:");
            int Aid=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter cust Name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter acc balance:");
            int Abc = Convert.ToInt32(Console.ReadLine());

            Account obj = null;
            Console.WriteLine("enter acc type");
            string type = Console.ReadLine();

            if(type == "Savings")
            {
                obj = new Saving(Aid, name, Abc);
            }
            else if (type == "Current")
                {
                    obj = new Current(Aid, name, Abc);
                }
            if (type != null)
            {
                obj.StopPayment();
                obj.BlockAcc();
                int AccBalance = obj.GetBalance();
                Console.WriteLine("balance" + AccBalance);
                Console.WriteLine("enter an amt to deposite");
                int amt = Convert.ToInt32(Console.ReadLine());
                obj.Deposite(amt);
                AccBalance = obj.GetBalance();
                Console.WriteLine("balance" + " "+AccBalance);
                Console.WriteLine("enter the amt to withdraw");
                 amt = Convert.ToInt32(Console.ReadLine());
                obj.Withdraw(amt);
                AccBalance = obj.GetBalance();
                Console.WriteLine("balance" +" "+ AccBalance);
              
            }
            Console.ReadLine();
        }
    }
}
