﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day2_Abstract_Account
{
    class Saving:Account
    {
        public Saving(int AccId,string CustomerName,int AccBalance):base(AccId,CustomerName,AccBalance)
        {
            Console.WriteLine("savings");
        }

        public override void Deposite(int amt)
        {
            this.AccBalance +=amt+100;
        }

        public override void Withdraw(int amt)
        {
            this.AccBalance -=amt+10;
        }
    }
}
