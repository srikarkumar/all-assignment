﻿namespace Win_threads
{
    partial class Frm_async
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_async = new System.Windows.Forms.Button();
            this.txtn2 = new System.Windows.Forms.TextBox();
            this.txtn1 = new System.Windows.Forms.TextBox();
            this.lbln2 = new System.Windows.Forms.Label();
            this.lbln1 = new System.Windows.Forms.Label();
            this.lbl_msg = new System.Windows.Forms.Label();
            this.lst_msg = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_async
            // 
            this.btn_async.Location = new System.Drawing.Point(419, 268);
            this.btn_async.Name = "btn_async";
            this.btn_async.Size = new System.Drawing.Size(274, 97);
            this.btn_async.TabIndex = 9;
            this.btn_async.Text = "async sum";
            this.btn_async.UseVisualStyleBackColor = true;
            this.btn_async.Click += new System.EventHandler(this.btn_async_Click);
            // 
            // txtn2
            // 
            this.txtn2.Location = new System.Drawing.Point(522, 177);
            this.txtn2.Name = "txtn2";
            this.txtn2.Size = new System.Drawing.Size(100, 26);
            this.txtn2.TabIndex = 8;
            // 
            // txtn1
            // 
            this.txtn1.Location = new System.Drawing.Point(522, 78);
            this.txtn1.Name = "txtn1";
            this.txtn1.Size = new System.Drawing.Size(100, 26);
            this.txtn1.TabIndex = 7;
            // 
            // lbln2
            // 
            this.lbln2.AutoSize = true;
            this.lbln2.Location = new System.Drawing.Point(367, 184);
            this.lbln2.Name = "lbln2";
            this.lbln2.Size = new System.Drawing.Size(72, 20);
            this.lbln2.TabIndex = 6;
            this.lbln2.Text = "number2";
            // 
            // lbln1
            // 
            this.lbln1.AutoSize = true;
            this.lbln1.Location = new System.Drawing.Point(363, 78);
            this.lbln1.Name = "lbln1";
            this.lbln1.Size = new System.Drawing.Size(72, 20);
            this.lbln1.TabIndex = 5;
            this.lbln1.Text = "number1";
            // 
            // lbl_msg
            // 
            this.lbl_msg.AutoSize = true;
            this.lbl_msg.Location = new System.Drawing.Point(83, 235);
            this.lbl_msg.Name = "lbl_msg";
            this.lbl_msg.Size = new System.Drawing.Size(0, 20);
            this.lbl_msg.TabIndex = 10;
            // 
            // lst_msg
            // 
            this.lst_msg.FormattingEnabled = true;
            this.lst_msg.ItemHeight = 20;
            this.lst_msg.Location = new System.Drawing.Point(28, 65);
            this.lst_msg.Name = "lst_msg";
            this.lst_msg.Size = new System.Drawing.Size(258, 204);
            this.lst_msg.TabIndex = 11;
            // 
            // Frm_async
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 419);
            this.Controls.Add(this.lst_msg);
            this.Controls.Add(this.lbl_msg);
            this.Controls.Add(this.btn_async);
            this.Controls.Add(this.txtn2);
            this.Controls.Add(this.txtn1);
            this.Controls.Add(this.lbln2);
            this.Controls.Add(this.lbln1);
            this.Name = "Frm_async";
            this.Text = "Frm_async";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_async;
        private System.Windows.Forms.TextBox txtn2;
        private System.Windows.Forms.TextBox txtn1;
        private System.Windows.Forms.Label lbln2;
        private System.Windows.Forms.Label lbln1;
        private System.Windows.Forms.Label lbl_msg;
        private System.Windows.Forms.ListBox lst_msg;
    }
}