﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Win_threads
{
    public partial class Frm_async : Form
    {
        public delegate int delthread(int n1, int n2);

        public int getsum(int n1,int n2)
        {
            Thread.Sleep(5000);
            return n1 + n2;
        }
        public delegate void del();
        public void callback(IAsyncResult res)
        {
            int returnvalue = d.EndInvoke(res);
            //  MessageBox.Show("get sum called:"+res.AsyncState+" ::"+returnvalue);
            del obj = new del(() => {
            lst_msg.Items.Add(res.AsyncState + ":  " + returnvalue);
            });
            this.BeginInvoke(obj);

        }
        public Frm_async()
        {
            InitializeComponent();
        }
        delthread d;

        private void btn_async_Click(object sender, EventArgs e)
        {
            if (d == null)
            {
                d = new delthread(this.getsum);
            }
            int n1 = Convert.ToInt32(txtn1.Text);
            int n2 = Convert.ToInt32(txtn2.Text);

            string str = n1 + " + " + n2;
            d.BeginInvoke(n1, n2, callback, str); //new thread creates
           // d.BeginInvoke(10, 20, callback, "1002");
        }
    }
}
