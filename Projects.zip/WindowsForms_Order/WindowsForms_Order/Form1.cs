﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_Order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
           

        private void btn_placeorder_Click(object sender, EventArgs e)
        {


            if (txt_orderid.Text == string.Empty)
            {
                MessageBox.Show("enter order id");
            }
            else if (txt_custname.Text == string.Empty)
            {
                MessageBox.Show("enter order customername");
            }
            else if (txt_itemid.Text == string.Empty)
            {
                MessageBox.Show("enter item id");
            }
            else if (txt_itemqty.Text == string.Empty)
            {
                MessageBox.Show("enter item quantity");
            }
            else if (txt_itemprice.Text == string.Empty)
            {
                MessageBox.Show("enter item price");
            }
            else if (txt_deliveryadd.Text == string.Empty)
            {
                MessageBox.Show("enter delivery address");
            }

            else if (cmb_city.Text == string.Empty)
            {
                MessageBox.Show("select city");
            }
            else if (rdb_online.Checked == false && rdb_cash.Checked == false)
            {
                MessageBox.Show("Select method");
            }

            else
            {
                int id = Convert.ToInt32(txt_orderid.Text);

                string name = txt_custname.Text;

                int iid = Convert.ToInt32(txt_itemid.Text);

                int qty = Convert.ToInt32(txt_itemqty.Text);

                int price = Convert.ToInt32(txt_itemprice.Text);

                string add = txt_deliveryadd.Text;

                string city = cmb_city.Text;


                string method = string.Empty;
                if (rdb_online.Checked)
                {
                    method = "online";
                }
                else
                {
                    method = "cash";
                }
              

                Order obj = new Order(id, name, iid, qty, price, add, city, method);
                int value = obj.GetOrderValue();
                MessageBox.Show(value.ToString());
            }

            }
       

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_city.Items.Add("hyd");
            cmb_city.Items.Add("bng");
            cmb_city.Items.Add("chennai");
        
    }

        
    }

       
    }

