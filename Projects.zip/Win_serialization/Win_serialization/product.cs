﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_serialization
{
    [Serializable]//attribute like mata data.
   public class product
    {
        public int productid { get; set; }
        public string productname { get; set; }
        public int productprice { get; set; }

    }
}
