﻿namespace Win_serialization
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnser = new System.Windows.Forms.Button();
            this.btndeser = new System.Windows.Forms.Button();
            this.lblid = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblprice = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.btnxml = new System.Windows.Forms.Button();
            this.btndexml = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnser
            // 
            this.btnser.Location = new System.Drawing.Point(122, 213);
            this.btnser.Name = "btnser";
            this.btnser.Size = new System.Drawing.Size(197, 73);
            this.btnser.TabIndex = 0;
            this.btnser.Text = "serialization";
            this.btnser.UseVisualStyleBackColor = true;
            this.btnser.Click += new System.EventHandler(this.btnser_Click);
            // 
            // btndeser
            // 
            this.btndeser.Location = new System.Drawing.Point(386, 213);
            this.btndeser.Name = "btndeser";
            this.btndeser.Size = new System.Drawing.Size(197, 73);
            this.btndeser.TabIndex = 1;
            this.btndeser.Text = "deserialization";
            this.btndeser.UseVisualStyleBackColor = true;
            this.btndeser.Click += new System.EventHandler(this.button2_Click);
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(58, 32);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(79, 20);
            this.lblid.TabIndex = 2;
            this.lblid.Text = "product id";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(30, 97);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(107, 20);
            this.lblname.TabIndex = 3;
            this.lblname.Text = "product name";
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.Location = new System.Drawing.Point(30, 161);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(101, 20);
            this.lblprice.TabIndex = 4;
            this.lblprice.Text = "product price";
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(187, 32);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(208, 26);
            this.txtid.TabIndex = 5;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(187, 97);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(208, 26);
            this.txtname.TabIndex = 6;
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(187, 154);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(208, 26);
            this.txtprice.TabIndex = 7;
            // 
            // btnxml
            // 
            this.btnxml.Location = new System.Drawing.Point(122, 306);
            this.btnxml.Name = "btnxml";
            this.btnxml.Size = new System.Drawing.Size(197, 73);
            this.btnxml.TabIndex = 8;
            this.btnxml.Text = "xml serialization";
            this.btnxml.UseVisualStyleBackColor = true;
            this.btnxml.Click += new System.EventHandler(this.btnxml_Click);
            // 
            // btndexml
            // 
            this.btndexml.Location = new System.Drawing.Point(386, 306);
            this.btndexml.Name = "btndexml";
            this.btndexml.Size = new System.Drawing.Size(197, 73);
            this.btndexml.TabIndex = 9;
            this.btndexml.Text = "xml deserialization";
            this.btndexml.UseVisualStyleBackColor = true;
            this.btndexml.Click += new System.EventHandler(this.btndexml_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 391);
            this.Controls.Add(this.btndexml);
            this.Controls.Add(this.btnxml);
            this.Controls.Add(this.txtprice);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.lblprice);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblid);
            this.Controls.Add(this.btndeser);
            this.Controls.Add(this.btnser);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnser;
        private System.Windows.Forms.Button btndeser;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.Button btnxml;
        private System.Windows.Forms.Button btndexml;
    }
}

