﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class Frm_showemp : Form
    {
        public Frm_showemp()
        {
            InitializeComponent();
        }

        private void txtcity_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnfind_Click(object sender, EventArgs e)
        {
            employee1DAL dal = new employee1DAL();
            string city = txtcity.Text;
            List<employee1> list = dal.showemployees(city);
            dgemployees.DataSource = list;
        }

        private void btnsearchall_Click(object sender, EventArgs e)
        {
            employee1DAL dal = new employee1DAL();
            string key = txtsearch.Text;
            List<employee1> list = dal.searchemployees(key);
            dgemployees.DataSource = list;
        }
    }
}
