﻿namespace Win_ado
{
    partial class Frm_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lblpassword = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.btnfind = new System.Windows.Forms.Button();
            this.lblempdoj = new System.Windows.Forms.Label();
            this.txtempdoj = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnupdate
            // 
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(651, 173);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(154, 60);
            this.btnupdate.TabIndex = 15;
            this.btnupdate.Text = "update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btndelete
            // 
            this.btndelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.Location = new System.Drawing.Point(640, 268);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(183, 75);
            this.btndelete.TabIndex = 14;
            this.btndelete.Text = "delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // txtpassword
            // 
            this.txtpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.Location = new System.Drawing.Point(205, 213);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(234, 35);
            this.txtpassword.TabIndex = 13;
            // 
            // txtcity
            // 
            this.txtcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcity.Location = new System.Drawing.Point(205, 129);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(234, 35);
            this.txtcity.TabIndex = 12;
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(205, 62);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(234, 35);
            this.txtname.TabIndex = 11;
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Location = new System.Drawing.Point(48, 213);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(112, 20);
            this.lblpassword.TabIndex = 10;
            this.lblpassword.Text = "emp password";
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Location = new System.Drawing.Point(54, 129);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(63, 20);
            this.lblcity.TabIndex = 9;
            this.lblcity.Text = "empcity";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(46, 62);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(80, 20);
            this.lblname.TabIndex = 8;
            this.lblname.Text = "empname";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(48, 13);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(56, 20);
            this.lblid.TabIndex = 16;
            this.lblid.Text = "emp id";
            // 
            // txtid
            // 
            this.txtid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtid.Location = new System.Drawing.Point(205, 12);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(234, 35);
            this.txtid.TabIndex = 17;
            // 
            // btnfind
            // 
            this.btnfind.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfind.Location = new System.Drawing.Point(640, 45);
            this.btnfind.Name = "btnfind";
            this.btnfind.Size = new System.Drawing.Size(154, 68);
            this.btnfind.TabIndex = 18;
            this.btnfind.Text = "find";
            this.btnfind.UseVisualStyleBackColor = true;
            this.btnfind.Click += new System.EventHandler(this.btnfind_Click);
            // 
            // lblempdoj
            // 
            this.lblempdoj.AutoSize = true;
            this.lblempdoj.Location = new System.Drawing.Point(61, 268);
            this.lblempdoj.Name = "lblempdoj";
            this.lblempdoj.Size = new System.Drawing.Size(65, 20);
            this.lblempdoj.TabIndex = 19;
            this.lblempdoj.Text = "emp doj";
            // 
            // txtempdoj
            // 
            this.txtempdoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtempdoj.Location = new System.Drawing.Point(205, 268);
            this.txtempdoj.Name = "txtempdoj";
            this.txtempdoj.Size = new System.Drawing.Size(244, 35);
            this.txtempdoj.TabIndex = 20;
            // 
            // Frm_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1030, 448);
            this.Controls.Add(this.txtempdoj);
            this.Controls.Add(this.lblempdoj);
            this.Controls.Add(this.btnfind);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.lblid);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblpassword);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.lblname);
            this.Name = "Frm_find";
            this.Text = "Frm_find";
            this.Load += new System.EventHandler(this.Frm_find_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.Button btnfind;
        private System.Windows.Forms.Label lblempdoj;
        private System.Windows.Forms.TextBox txtempdoj;
    }
}