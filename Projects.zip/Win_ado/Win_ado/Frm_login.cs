﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class Frm_login : Form
    {
        public Frm_login()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string id = txtid.Text;
            string password = txtpassword.Text;
            try
            {
                employee1DAL dal = new employee1DAL();
                
                

                bool status = dal.login(id, password);

                if (status)
                {
                    MessageBox.Show("successfully login");

                }
                else
                {
                    MessageBox.Show("invalid id and password");
                }
            }
            catch(System.Data.SqlClient.SqlException exp)
            {
                MessageBox.Show("sql error");
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            finally { MessageBox.Show("finally block"); }
        }

        private void btnsqlloging_Click(object sender, EventArgs e)
        {
            string id = txtid.Text;
            string password = txtpassword.Text;

            employee1DAL dal = new employee1DAL();
            bool status = dal.logininjection(id, password);
            if (status) {
                MessageBox.Show("valid user"); }
            else { MessageBox.Show("invalid user"); }
        }
    }
}
