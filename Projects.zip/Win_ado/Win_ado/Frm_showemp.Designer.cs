﻿namespace Win_ado
{
    partial class Frm_showemp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblcity = new System.Windows.Forms.Label();
            this.lblsearch = new System.Windows.Forms.Label();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btnfind = new System.Windows.Forms.Button();
            this.btnsearchall = new System.Windows.Forms.Button();
            this.dgemployees = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgemployees)).BeginInit();
            this.SuspendLayout();
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcity.Location = new System.Drawing.Point(183, 50);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(84, 25);
            this.lblcity.TabIndex = 0;
            this.lblcity.Text = "emp city";
            // 
            // lblsearch
            // 
            this.lblsearch.AutoSize = true;
            this.lblsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsearch.Location = new System.Drawing.Point(203, 121);
            this.lblsearch.Name = "lblsearch";
            this.lblsearch.Size = new System.Drawing.Size(71, 25);
            this.lblsearch.TabIndex = 1;
            this.lblsearch.Text = "search";
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(304, 44);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(181, 26);
            this.txtcity.TabIndex = 2;
            this.txtcity.TextChanged += new System.EventHandler(this.txtcity_TextChanged);
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(304, 120);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(197, 26);
            this.txtsearch.TabIndex = 3;
            // 
            // btnfind
            // 
            this.btnfind.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfind.Location = new System.Drawing.Point(574, 19);
            this.btnfind.Name = "btnfind";
            this.btnfind.Size = new System.Drawing.Size(126, 70);
            this.btnfind.TabIndex = 4;
            this.btnfind.Text = "find";
            this.btnfind.UseVisualStyleBackColor = true;
            this.btnfind.Click += new System.EventHandler(this.btnfind_Click);
            // 
            // btnsearchall
            // 
            this.btnsearchall.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchall.Location = new System.Drawing.Point(564, 121);
            this.btnsearchall.Name = "btnsearchall";
            this.btnsearchall.Size = new System.Drawing.Size(159, 67);
            this.btnsearchall.TabIndex = 5;
            this.btnsearchall.Text = "search(all)";
            this.btnsearchall.UseVisualStyleBackColor = true;
            this.btnsearchall.Click += new System.EventHandler(this.btnsearchall_Click);
            // 
            // dgemployees
            // 
            this.dgemployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgemployees.Location = new System.Drawing.Point(12, 221);
            this.dgemployees.Name = "dgemployees";
            this.dgemployees.RowTemplate.Height = 28;
            this.dgemployees.Size = new System.Drawing.Size(879, 240);
            this.dgemployees.TabIndex = 6;
            // 
            // Frm_showemp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 516);
            this.Controls.Add(this.dgemployees);
            this.Controls.Add(this.btnsearchall);
            this.Controls.Add(this.btnfind);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.lblsearch);
            this.Controls.Add(this.lblcity);
            this.Name = "Frm_showemp";
            this.Text = "Frm_showemp";
            ((System.ComponentModel.ISupportInitialize)(this.dgemployees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblsearch;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btnfind;
        private System.Windows.Forms.Button btnsearchall;
        private System.Windows.Forms.DataGridView dgemployees;
    }
}