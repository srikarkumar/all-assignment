﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace Win_ado
{
    class employee1DAL
    {
        SqlConnection con = new SqlConnection
           (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int Addemployee(employee1 emp)
        {
            SqlCommand com_emp_insert = new SqlCommand
                ("p_addemployee", con);

            com_emp_insert.Parameters.AddWithValue("@name", emp.empname);
            com_emp_insert.Parameters.AddWithValue("@city", emp.empcity);
            com_emp_insert.Parameters.AddWithValue("@password", emp.emppassword);
            com_emp_insert.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_emp_insert.Parameters.Add(retdata);

            con.Open();
            com_emp_insert.ExecuteNonQuery();
            con.Close();

            int id = Convert.ToInt32(retdata.Value);
            
            return id;

        }
        public employee1 find(int id)
        {
            SqlCommand com_find = new SqlCommand("p_empdetails", con);
            com_find.Parameters.AddWithValue("@id", id);
            com_find.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                employee1 e = new employee1();
                e.empid = dr.GetInt32(0);
                e.empname = dr.GetString(1);
                e.empcity = dr.GetString(2);
                e.emppassword = dr.GetString(3);
                e.empdoj = dr.GetDateTime(4);
                con.Close();
                return e;
            }
            else
            {
                return null;
            }
        }

        public bool update(int id, string city, string password)
        {
            SqlCommand com_update = new SqlCommand
                ("p_updateemp", con);

            com_update.Parameters.AddWithValue("@id", id);
            com_update.Parameters.AddWithValue("@city", city);
            com_update.Parameters.AddWithValue("@password", password);
            com_update.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_update.Parameters.Add(retdata);

            con.Open();
            com_update.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
          
            if (count > 0)
            {
                return true;
            }
            else { return false; }

        }

        public bool Delete(int id)
        {
            SqlCommand com_delete = new SqlCommand("p_deleteemp", con);
            com_delete.Parameters.AddWithValue("@id", id);
            com_delete.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_delete.Parameters.Add(retdata);
                con.Open();
            com_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);

            if (count > 0) { return true; }
            else { return false; }

        }
        public List<employee1> showemployees(string city)
        {
            SqlCommand com_employees = new SqlCommand
                ("p_showemp", con);
            com_employees.Parameters.AddWithValue("@city", city);
            com_employees.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_employees.ExecuteReader();
            List<employee1> emplist = new List<employee1>();
            while (dr.Read())
            {
                employee1 obj = new employee1();
                obj.empid = dr.GetInt32(0);
                obj.empname = dr.GetString(1);
                obj.empcity = dr.GetString(2);
                obj.emppassword = dr.GetString(3);
                obj.empdoj = dr.GetDateTime(4);
                emplist.Add(obj);

            }
            con.Close();
            return emplist;


        }
        public List<employee1> searchemployees(string search)
        {
            SqlCommand com_search = new SqlCommand("p_searchemp", con);
            com_search.Parameters.AddWithValue("@key", search);
            com_search.CommandType = CommandType.StoredProcedure;

            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<employee1> emplist = new List<employee1>();
            while (dr.Read())
            {
                employee1 obj = new employee1();
                obj.empid = dr.GetInt32(0);
                obj.empname = dr.GetString(1);
                obj.empcity = dr.GetString(2);
                obj.emppassword = dr.GetString(3);
                obj.empdoj = dr.GetDateTime(4);
                emplist.Add(obj);

            }
            con.Close();
            return emplist;

        }

        public bool login(string id, string password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("p_login1", con);

                com_login.Parameters.AddWithValue("@id", id);
                com_login.Parameters.AddWithValue("@password", password);

                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(retdata);

                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);

                if (count > 0) { return true; }
                else { return false; }
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("finally");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        

        public bool logininjection(string id, string password)
        {
            SqlCommand com_login = new SqlCommand("select count(*) from tbl_employees1 where empid='" + id + "' and emppassword='" + password + "'", con);


            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0) { return true; }
            else { return false; }

        }
    }
}

