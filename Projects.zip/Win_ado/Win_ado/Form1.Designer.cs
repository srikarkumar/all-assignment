﻿namespace Win_ado
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblname = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblpassword = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.btnnewemp = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(107, 46);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(80, 20);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "empname";
            this.lblname.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Location = new System.Drawing.Point(111, 101);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(63, 20);
            this.lblcity.TabIndex = 1;
            this.lblcity.Text = "empcity";
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Location = new System.Drawing.Point(111, 159);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(112, 20);
            this.lblpassword.TabIndex = 2;
            this.lblpassword.Text = "emp password";
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(279, 46);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(234, 30);
            this.txtname.TabIndex = 3;
            // 
            // txtcity
            // 
            this.txtcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcity.Location = new System.Drawing.Point(279, 101);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(234, 30);
            this.txtcity.TabIndex = 4;
            // 
            // txtpassword
            // 
            this.txtpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.Location = new System.Drawing.Point(279, 156);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(234, 30);
            this.txtpassword.TabIndex = 5;
            // 
            // btnnewemp
            // 
            this.btnnewemp.Location = new System.Drawing.Point(125, 243);
            this.btnnewemp.Name = "btnnewemp";
            this.btnnewemp.Size = new System.Drawing.Size(183, 75);
            this.btnnewemp.TabIndex = 6;
            this.btnnewemp.Text = "new employee";
            this.btnnewemp.UseVisualStyleBackColor = true;
            this.btnnewemp.Click += new System.EventHandler(this.btnnewemp_Click);
            // 
            // btnreset
            // 
            this.btnreset.Location = new System.Drawing.Point(496, 243);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(154, 60);
            this.btnreset.TabIndex = 7;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = true;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 407);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btnnewemp);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblpassword);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.lblname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.Button btnnewemp;
        private System.Windows.Forms.Button btnreset;
    }
}

