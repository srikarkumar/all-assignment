﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtname.Text = string.Empty;
            txtpassword.Text = string.Empty;
            txtcity.Text = string.Empty;
        }

        private void btnnewemp_Click(object sender, EventArgs e)
        {
            if (txtname.Text == string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if (txtcity.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txtpassword.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                string name = txtname.Text;
                string city = txtcity.Text;
                string password = txtpassword.Text;
                employee1 obj = new employee1();
                obj.empname = name;
                obj.empcity = city;
                obj.emppassword = password;

                employee1DAL dal = new employee1DAL();
                int id = dal.Addemployee(obj);
                MessageBox.Show("employee added:" + id);


            }
        }
    }
}
