﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prct1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter n");

            int n = Convert.ToInt32(Console.ReadLine());
            int d = n - 51;

            if (n > 51)
            {
                 d*=3;
            };
            Console.WriteLine(d);
            Console.ReadLine();


        }
    }
}
