﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day3_Overriding_Order
{
    class Order
    {
        private int OrderId;
        private string CustomerName;
        private int ItemQuantity;
        private int ItemPrice; 
        public static int count =1000;

        public string PCustomerName
        {
            get { return this.CustomerName; }
        }
        public int PItemQuantity
        {
            get { return this.ItemQuantity; }
        }
        public int PItemPrice
        {
            get { return this.ItemPrice; }
        }
        public int POrderId {
            get
            { return this.OrderId; } }
        public Order(string CustomerName,int ItemQuantity,int ItemPrice)
        {
            Order.count++;
            this.OrderId = Order.count;
            this.CustomerName = CustomerName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
        }
        public virtual int GetOrderValue()
        {
            int amount = ItemPrice * ItemQuantity;
            return amount;
        }


    }
}
