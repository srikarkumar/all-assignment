﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_Structure
{
    class Program
    {
        static void Main(string[] args)
        {
            Book b1 = new Book(1, "aaaa");//stack value.
            Book b2 = new Book(2, "bbbb");

            Console.WriteLine(b1.PName+" "+b2.PName);

            b1 = b2;
            Console.WriteLine(b1.PName + " " + b2.PName);

            b2.PName = "ttt";
            Console.WriteLine(b1.PName + " " + b2.PName);
            Console.ReadLine();

        }
    }
}
