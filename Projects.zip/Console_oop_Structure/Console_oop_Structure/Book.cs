﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_Structure
{
    struct Book
    {
        private int ID;
        private string Name;

        public Book(int ID, string Name)
        {
            this.ID = ID;
            this.Name = Name;
        }
        public int PID { get { return this.ID; } }
        public string PName { get { return this.Name; } set { this.Name = value; } }

    }    
}
