﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_attributes
{
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Method)]
    class dev_attribute:Attribute
    {
        public string devid { get; set; }
        public string devname { get; set; }

        public dev_attribute(string devid,string devname)
        {
            this.devid = devid;
            this.devname = devname;

        }
    }
}
