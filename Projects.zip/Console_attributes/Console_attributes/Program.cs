﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Console_attributes
{
    class Program
    {
        static void Main(string[] args)
        {
            // test obj = new test();
            //obj.call();
            Type t = typeof(test);
            dev_attribute att = Attribute.GetCustomAttribute(t, typeof(dev_attribute)) as dev_attribute;

            Console.WriteLine(att.devid + "" + att.devname);

            foreach(MethodInfo m in t.GetMethods())
            {
                dev_attribute attmethod = Attribute.GetCustomAttribute(m, typeof(dev_attribute)) as dev_attribute;
                if (attmethod != null)
                {
                    Console.WriteLine(m.Name+""+)
                }
            }






            Console.ReadLine();
        }
    }
}
