﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day1_basics
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the num 1:");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the num 2:");
            int num2 = Convert.ToInt32(Console.ReadLine());

            int count = num1 += num2;
            Console.WriteLine("count is:" + count);

            Console.ReadLine();


        }
    }
}
