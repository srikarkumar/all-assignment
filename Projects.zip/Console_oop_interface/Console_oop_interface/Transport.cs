﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_oop_interface
{
    class Transport
    {
        public void Send(IProductTransport obj)
        {
            string Address = obj.GetAddress();
            Console.WriteLine("Delivery Adress:" + Address);
        }
    }
}
