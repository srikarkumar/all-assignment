﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_threads_assign
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        calc c = new calc();

        private async void btnadd_Click(object sender, EventArgs e)
        {
            double i = Convert.ToDouble(txtn1.Text);
            double j = Convert.ToDouble(txtn2.Text);

            var t = c.getcalc(i, j, "+");
            var result = await t;
            lstresult.Items.Add(i + " " + j + " " + result);
        }

        private async void btnsub_Click(object sender, EventArgs e)
        {
            double i = Convert.ToDouble(txtn1.Text);
            double j = Convert.ToDouble(txtn2.Text);

            var t = c.getcalc(i, j, "-");
            var result = await t;
            lstresult.Items.Add(i + " " + j + " " + result);


        }
    }
}
