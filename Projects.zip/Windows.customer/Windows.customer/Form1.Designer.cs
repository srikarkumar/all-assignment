﻿namespace Windows.customer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblcustid = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblpassword = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lbladd = new System.Windows.Forms.Label();
            this.lblmobile = new System.Windows.Forms.Label();
            this.lblmailid = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.txtadd = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtmailid = new System.Windows.Forms.TextBox();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnfind = new System.Windows.Forms.Button();
            this.btndalete = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblcustid
            // 
            this.lblcustid.AutoSize = true;
            this.lblcustid.Location = new System.Drawing.Point(102, 43);
            this.lblcustid.Name = "lblcustid";
            this.lblcustid.Size = new System.Drawing.Size(91, 20);
            this.lblcustid.TabIndex = 0;
            this.lblcustid.Text = "customer id";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(106, 94);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(119, 20);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "customer name";
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Location = new System.Drawing.Point(106, 145);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(147, 20);
            this.lblpassword.TabIndex = 2;
            this.lblpassword.Text = "customer password";
            this.lblpassword.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Location = new System.Drawing.Point(106, 195);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(102, 20);
            this.lblcity.TabIndex = 3;
            this.lblcity.Text = "customer city";
            // 
            // lbladd
            // 
            this.lbladd.AutoSize = true;
            this.lbladd.Location = new System.Drawing.Point(110, 253);
            this.lbladd.Name = "lbladd";
            this.lbladd.Size = new System.Drawing.Size(136, 20);
            this.lbladd.TabIndex = 4;
            this.lbladd.Text = "customer address";
            // 
            // lblmobile
            // 
            this.lblmobile.AutoSize = true;
            this.lblmobile.Location = new System.Drawing.Point(114, 312);
            this.lblmobile.Name = "lblmobile";
            this.lblmobile.Size = new System.Drawing.Size(125, 20);
            this.lblmobile.TabIndex = 5;
            this.lblmobile.Text = "customer mobile";
            // 
            // lblmailid
            // 
            this.lblmailid.AutoSize = true;
            this.lblmailid.Location = new System.Drawing.Point(114, 362);
            this.lblmailid.Name = "lblmailid";
            this.lblmailid.Size = new System.Drawing.Size(119, 20);
            this.lblmailid.TabIndex = 6;
            this.lblmailid.Text = "customer mailid";
            this.lblmailid.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(321, 43);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(100, 26);
            this.txtid.TabIndex = 7;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(321, 94);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 26);
            this.txtname.TabIndex = 8;
            this.txtname.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(321, 145);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(100, 26);
            this.txtpassword.TabIndex = 9;
            // 
            // txtmobile
            // 
            this.txtmobile.Location = new System.Drawing.Point(321, 312);
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(100, 26);
            this.txtmobile.TabIndex = 12;
            // 
            // txtadd
            // 
            this.txtadd.Location = new System.Drawing.Point(321, 253);
            this.txtadd.Name = "txtadd";
            this.txtadd.Size = new System.Drawing.Size(100, 26);
            this.txtadd.TabIndex = 11;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(321, 195);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(100, 26);
            this.txtcity.TabIndex = 10;
            // 
            // txtmailid
            // 
            this.txtmailid.Location = new System.Drawing.Point(321, 362);
            this.txtmailid.Name = "txtmailid";
            this.txtmailid.Size = new System.Drawing.Size(100, 26);
            this.txtmailid.TabIndex = 13;
            // 
            // btnadd
            // 
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(695, 71);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(116, 43);
            this.btnadd.TabIndex = 14;
            this.btnadd.Text = "add student";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnfind
            // 
            this.btnfind.Location = new System.Drawing.Point(695, 159);
            this.btnfind.Name = "btnfind";
            this.btnfind.Size = new System.Drawing.Size(116, 56);
            this.btnfind.TabIndex = 15;
            this.btnfind.Text = "find";
            this.btnfind.UseVisualStyleBackColor = true;
            this.btnfind.Click += new System.EventHandler(this.btnfind_Click);
            // 
            // btndalete
            // 
            this.btndalete.Location = new System.Drawing.Point(695, 338);
            this.btndalete.Name = "btndalete";
            this.btndalete.Size = new System.Drawing.Size(123, 44);
            this.btndalete.TabIndex = 17;
            this.btndalete.Text = "delete";
            this.btndalete.UseVisualStyleBackColor = true;
            this.btndalete.Click += new System.EventHandler(this.btndalete_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(695, 250);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(123, 48);
            this.btnupdate.TabIndex = 16;
            this.btnupdate.Text = "update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1159, 499);
            this.Controls.Add(this.btndalete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnfind);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.txtmailid);
            this.Controls.Add(this.txtmobile);
            this.Controls.Add(this.txtadd);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.lblmailid);
            this.Controls.Add(this.lblmobile);
            this.Controls.Add(this.lbladd);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.lblpassword);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblcustid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblcustid;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lbladd;
        private System.Windows.Forms.Label lblmobile;
        private System.Windows.Forms.Label lblmailid;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.TextBox txtadd;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtmailid;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnfind;
        private System.Windows.Forms.Button btndalete;
        private System.Windows.Forms.Button btnupdate;
    }
}

