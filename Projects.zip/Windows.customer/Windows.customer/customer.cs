﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows.customer
{
    class customer
    {
        public int custid { get; set; }
        public string custname { get; set; }
        public string custpassword { get; set; }
        public string custcity { get; set; }
        public string custadd { get; set; }
        public string custmobile { get; set; }
        public string custmailid { get; set; }
    }
}
