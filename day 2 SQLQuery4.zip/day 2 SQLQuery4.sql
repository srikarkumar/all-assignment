create database bankdb

use bankdb

create table tbl_custometinfo(
customerid int identity(100,1) primary key,
customername varchar(100) not null,
customercity varchar(100) not null,
customeradd varchar(100) not null,
customermobile varchar(100) unique,
pan varchar(100) unique,
customerpassword varchar(100) not null
)
insert tbl_custometinfo values('srikar','hyd','madhapur','1456','asdm1235','abc11def')
insert tbl_custometinfo values('sridher','pune','madhr','1236','asdn1235','abcd22ef')
insert tbl_custometinfo values('swathi','hyd','madhapur','1234556','asdo1235','ab88cdef')
insert tbl_custometinfo values('venkat','chennai','madr','12356','asdp1235','88abcdef')
insert tbl_custometinfo values('rahul','bng','btm','145666','asdh1q235','abcde99f')
insert tbl_custometinfo values('vinat','bng','btm','1234f5886','asdr1235','ab4cdef')
insert tbl_custometinfo values('srikanth','hyd','madhapur','1211rroi3456','asd1235','abc33def')
insert tbl_custometinfo values('srighr','viz','beach','1232456','asd1std235','abcd22ef')
insert tbl_custometinfo values('srifcdar','viz','beach','1239456','asdgf1235','abc4def')
insert tbl_custometinfo values('sff','hyd','madhapur','12343356','asd1ag235','abcd4ef')

select * from tbl_custometinfo


create table tbl_accountinfo(
accountid int identity(10000,1) primary key,
customerid int not null foreign key references tbl_custometinfo(customerid),
accounttype varchar(100),
accountbalance int,
accountopendate date,
accountstatus varchar(100)
)
insert tbl_accountinfo values(100,'savings',10000,'10-4-2014','open')
insert tbl_accountinfo values(100,'current',20000,'11-4-2013','close')
insert tbl_accountinfo values(101,'current',50000,'10-2-2017','open')
insert tbl_accountinfo values(101,'savings',18000,'1-4-2014','open')
insert tbl_accountinfo values(105,'savings',10300,'10-6-2013','blocked')
insert tbl_accountinfo values(104,'current',14500,'12-4-2012','open')
insert tbl_accountinfo values(106,'savings',10800,'4-7-2014','blocked')
insert tbl_accountinfo values(107,'current',15800,'4-4-2017','open')
insert tbl_accountinfo values(106,'current',17800,'5-4-2011','closed')
insert tbl_accountinfo values(103,'current',10300,'10-4-2008','open')

select * from tbl_accountinfo

create table tbl_transactioninfo(
transactionid int identity(1,1) primary key,
accountid int not null foreign key references tbl_accountinfo,
transactiontype varchar(100),
amount int check(amount>0),
transactiondate date)

insert tbl_transactioninfo values(10000,'with',1000,'10-12-2017')
insert tbl_transactioninfo values(10000,'dep',1080,'10-2-2017')
insert tbl_transactioninfo values(10001,'with',1440,'11-12-2016')
insert tbl_transactioninfo values(10002,'tran',1050,'1-2-2017')
insert tbl_transactioninfo values(10003,'dep',100,'2-12-2014')
insert tbl_transactioninfo values(10004,'with',1100,'10-12-2014')
insert tbl_transactioninfo values(10004,'tran',1007,'1-12-2017')
insert tbl_transactioninfo values(10007,'tran',10,'10-12-2011')
insert tbl_transactioninfo values(10010,'with',2000,'8-1-2018')
insert tbl_transactioninfo values(10016,'dep',300,'10-12-2014')

select * from tbl_transactioninfo


--QUERIES--

select top 2 * from tbl_transactioninfo  where accountid=10000 order by transactiondate desc 


select * from tbl_transactioninfo where accountid=10000 and transactiondate between '01-01-2016' and '12-12-2017'


 select count(customerid) from tbl_accountinfo where customerid=100


 select tbl_custometinfo.customerid,tbl_custometinfo.customername,tbl_custometinfo.customeradd,
 tbl_custometinfo.customermobile,tbl_accountinfo.accountid,tbl_accountinfo.accountbalance 
 from tbl_custometinfo join tbl_accountinfo 
 on tbl_custometinfo.customerid=tbl_accountinfo.customerid


 select tbl_accountinfo.accountid,tbl_accountinfo.accountbalance,tbl_transactioninfo.transactionid,
 tbl_transactioninfo.amount,tbl_transactioninfo.transactiontype
 from tbl_accountinfo join tbl_transactioninfo
 on tbl_accountinfo.accountid=tbl_transactioninfo.accountid


 select tbl_custometinfo.customerid,tbl_custometinfo.customername,tbl_custometinfo.customeradd,
 tbl_custometinfo.customermobile,tbl_accountinfo.accountid,tbl_accountinfo.accountbalance,
 tbl_transactioninfo.transactionid,tbl_transactioninfo.amount,tbl_transactioninfo.transactiontype 
 from tbl_custometinfo join tbl_accountinfo 
 on tbl_custometinfo.customerid=tbl_accountinfo.customerid
 join tbl_transactioninfo
 on tbl_accountinfo.accountid=tbl_transactioninfo.accountid

 
 select * from tbl_custometinfo where customerid 
 in(select customerid from tbl_accountinfo)


  select * from tbl_custometinfo where customerid 
 not in(select customerid from tbl_accountinfo)

  select * from tbl_accountinfo where accountid
  in (select accountid from tbl_transactioninfo)

  select * from tbl_accountinfo where accountid
  not in (select accountid from tbl_transactioninfo)