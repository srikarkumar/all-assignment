﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day2_opps_single_ton
{
    class Manager
    {
        private int ManagerId;
        private string ManagerName;

        public int PManagerId { get { return this.ManagerId; } }
        public string PManagerName { get { return this.ManagerName; } }

        private Manager(int ManagerId, string ManagerName)
        {
            this.ManagerId = ManagerId;
            this.ManagerName = ManagerName;
        }
        static Manager m;
        public static Manager GetManager()
        {
            if(m==null)
            {
                m = new Manager(100, "sri");
            }
            return m;
        }


    }
}
